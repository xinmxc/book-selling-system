/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bundlebooks.bundlebooks;

/**
 *
 * @author Jason
 */
public class BundleBooks {

    public static void main(String[] args) {
        System.out.println("Initialising...");
	LoginFrame.main(args);
    }
}
