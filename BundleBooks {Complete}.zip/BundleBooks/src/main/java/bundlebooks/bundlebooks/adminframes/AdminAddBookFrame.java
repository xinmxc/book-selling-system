/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bundlebooks.bundlebooks.adminframes;
import bundlebooks.bundlebooks.classes.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class AdminAddBookFrame extends javax.swing.JFrame {
    private String Username;
    /**
     * Creates new form AdminAddBookFrame
     */
    public AdminAddBookFrame() {
        initComponents();
    }
    
    public AdminAddBookFrame(String username) {
        initComponents();
	this.setResizable(false);
	Username = username;
	this.DisplayBookCategories();
	this.DisplayBookID();
    }
    
    public void ClearAllTextFields() {
	txtBookTitle.setText("");
	txtBookAuthor.setText("");
	maskTxtBookPrice.setText("");
	txtBookQuantity.setText("");
    }
    
    public final void DisplayBookCategories() {
	CategoryFileHandler cfh = new CategoryFileHandler();
	ArrayList<Category> categoryArrList = cfh.ReadObjectFromCategoryFile();
	if (!categoryArrList.isEmpty()) {
	    for (Category category : categoryArrList) {
		cmbBookCategory.addItem(category.GetCategoryName());
	    }
	}
    }
    
    public final void DisplayBookID() {
	CategoryFileHandler cfh = new CategoryFileHandler();
	BookFileHandler bfh = new BookFileHandler();
	
	ArrayList<Category> categoryArrList = cfh.ReadObjectFromCategoryFile();
	ArrayList<Book> bookArrList = bfh.ReadObjectFromBookFile();
	if (categoryArrList.isEmpty()) {
	    lblErrMsg.setText("No categories FOUND! Please add them first before adding books");
	    btnConfirm.setEnabled(false);
	} else {
	    if (bookArrList.isEmpty()) {
		BookIDFormatter bkID = new BookIDFormatter();
		String FullBookID = bkID.BookIDFormatter(1);
		txtBookID.setText(FullBookID);
	    } else {
		Book lastBook = bookArrList.get(bookArrList.size() - 1);
		String lastBookID = lastBook.GetBookID();
		String[] section = lastBookID.split("(?<=\\D)(?=\\d)");
		int lastBkIDInteger = Integer.parseInt(section[1]);
		lastBkIDInteger += 1;
		BookIDFormatter bkID = new BookIDFormatter();
		String FullBookID = bkID.BookIDFormatter(lastBkIDInteger);
		txtBookID.setText(FullBookID);
	    }
	}
    }
    
    public void BookDetailsCreator() {
	String SelectedCategoryName = cmbBookCategory.getSelectedItem().toString();
	String DigitOnlyRegex = "\\d+";
	if (SelectedCategoryName.equals("Please Select One Category")) {
	    lblErrMsg.setText("Book Category has NOT BEEN SELECTED");
	} else if (txtBookTitle.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Title is EMPTY");
	} else if (txtBookAuthor.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Author is EMPTY");
	} else if (maskTxtBookPrice.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Price is EMPTY");
	} else if (txtBookQuantity.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Available Quantity is EMPTY");
	} else {
	    try {
		if (!txtBookQuantity.getText().trim().matches(DigitOnlyRegex)) {
		    lblErrMsg.setText("Book Available Quantity is INVALID");
		    txtBookQuantity.setText("");
		} else {
		    CategoryFileHandler cfh = new CategoryFileHandler();
		    ArrayList<Category> categoryArrList = cfh.ReadObjectFromCategoryFile();
		    StringFormatter CapitalFormat = new StringFormatter();
		    String BookCategoryID = "";
		    String BookCategoryName = "";
		    for (Category category : categoryArrList) {
			if (SelectedCategoryName.equals(category.GetCategoryName())) {
			    BookCategoryID = category.GetCategoryID();
			    BookCategoryName = category.GetCategoryName();
			    break;
			}
		    }
		    String BookID = txtBookID.getText();
		    String BookTitle = CapitalFormat.CapitaliseEachWord(txtBookTitle.getText().trim());
		    String BookAuthor = CapitalFormat.CapitaliseEachWord(txtBookAuthor.getText().trim());
		    double BookPrice = Double.parseDouble(maskTxtBookPrice.getText().trim());
		    int BookQuantity = Integer.parseInt(txtBookQuantity.getText().trim());
		    
		    BookFileHandler bfh = new BookFileHandler();
		    ArrayList<Book> bookArrList = bfh.ReadObjectFromBookFile();
		    boolean DuplicatedBook = false;
		    for (Book book : bookArrList) {
			if (!book.GetBookID().equals(BookID) && book.GetBookTitle().equals(BookTitle) && (book.GetBookAuthor().equals(BookAuthor))) {
			    // Diiferent book IDs with the same title and author
			    lblErrMsg.setText("Book already EXISTS! Please enter a unique book");
			    DuplicatedBook = true;
			    txtBookTitle.setText("");
			    txtBookAuthor.setText("");
			    break;
			}
		    }		    
		    if (!BookCategoryID.equals("") && !BookCategoryName.equals("") && DuplicatedBook == false) {
			Book book = new Book(BookCategoryID, BookCategoryName, BookID, BookTitle, BookAuthor, BookPrice, BookQuantity);
			bookArrList.add(book);
			bfh.WriteObjectToBookFile(bookArrList);
			lblErrMsg.setText("Book [Title: " + BookTitle + "] has been created");
			this.ClearAllTextFields();
		    }   
		}
	    } catch (NumberFormatException e) {
		System.out.println("ERROR Occured");
	    }
	}
	this.DisplayBookID();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblHeading = new javax.swing.JLabel();
        lblBookCategory = new javax.swing.JLabel();
        btnConfirm = new javax.swing.JButton();
        lblBookID = new javax.swing.JLabel();
        txtBookID = new javax.swing.JTextField();
        lblBookTitle = new javax.swing.JLabel();
        txtBookTitle = new javax.swing.JTextField();
        btnCancel = new javax.swing.JButton();
        txtBookQuantity = new javax.swing.JTextField();
        lblBookPrice = new javax.swing.JLabel();
        lblErrMsg = new javax.swing.JLabel();
        maskTxtBookPrice = new javax.swing.JFormattedTextField();
        lblBookQunatity = new javax.swing.JLabel();
        cmbBookCategory = new javax.swing.JComboBox<>();
        txtBookAuthor = new javax.swing.JTextField();
        lblBookAuthor = new javax.swing.JLabel();
        mnbAdminMain = new javax.swing.JMenuBar();
        mnuAdmin = new javax.swing.JMenu();
        mniAdminMainMenu = new javax.swing.JMenuItem();
        mniAdminAddAdmin = new javax.swing.JMenuItem();
        mniAdminSearchAdmin = new javax.swing.JMenuItem();
        mnuDeliveryStaff = new javax.swing.JMenu();
        mniAdminAddDS = new javax.swing.JMenuItem();
        mniAdminSearchDS = new javax.swing.JMenuItem();
        mniAdminAssignDS = new javax.swing.JMenuItem();
        mnuCategory = new javax.swing.JMenu();
        mniAdminAddCategory = new javax.swing.JMenuItem();
        mniAdminSearchCategory = new javax.swing.JMenuItem();
        mnuBook = new javax.swing.JMenu();
        mniAdminSearchBook = new javax.swing.JMenuItem();
        mnuRecords = new javax.swing.JMenu();
        mniAdminViewCategory = new javax.swing.JMenuItem();
        mniAdminViewBook = new javax.swing.JMenuItem();
        mniAdminViewCustomerOrder = new javax.swing.JMenuItem();
        mniAdminViewCustomerPayment = new javax.swing.JMenuItem();
        mniAdminSearchCustomer = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Book Creator");

        lblTitle.setFont(new java.awt.Font("Livvic", 1, 24)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Add Book");
        lblTitle.setMaximumSize(new java.awt.Dimension(150, 31));
        lblTitle.setMinimumSize(new java.awt.Dimension(150, 31));
        lblTitle.setPreferredSize(new java.awt.Dimension(150, 31));

        lblHeading.setFont(new java.awt.Font("Livvic", 1, 18)); // NOI18N
        lblHeading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHeading.setText("Please enter new book details");
        lblHeading.setToolTipText("");

        lblBookCategory.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookCategory.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookCategory.setText("Category:");

        btnConfirm.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnConfirm.setText("Confirm");
        btnConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmActionPerformed(evt);
            }
        });

        lblBookID.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookID.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookID.setText("Book ID:");

        txtBookID.setEditable(false);
        txtBookID.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookID.setMargin(new java.awt.Insets(5, 5, 5, 5));

        lblBookTitle.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookTitle.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookTitle.setText("Book Title:");

        txtBookTitle.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookTitle.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtBookTitle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBookTitleFocusGained(evt);
            }
        });

        btnCancel.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        txtBookQuantity.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookQuantity.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtBookQuantity.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBookQuantityFocusGained(evt);
            }
        });

        lblBookPrice.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookPrice.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookPrice.setText("Price RM:");

        lblErrMsg.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N

        maskTxtBookPrice.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat(""))));
        maskTxtBookPrice.setMargin(new java.awt.Insets(5, 5, 5, 5));
        maskTxtBookPrice.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                maskTxtBookPriceFocusGained(evt);
            }
        });

        lblBookQunatity.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookQunatity.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookQunatity.setText("Quantity:");

        cmbBookCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Please Select One Category" }));
        cmbBookCategory.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cmbBookCategoryFocusGained(evt);
            }
        });

        txtBookAuthor.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookAuthor.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtBookAuthor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBookAuthorFocusGained(evt);
            }
        });

        lblBookAuthor.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookAuthor.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookAuthor.setText("Book Author:");

        mnuAdmin.setText("Admin");

        mniAdminMainMenu.setText("Main Menu");
        mniAdminMainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminMainMenuActionPerformed(evt);
            }
        });
        mnuAdmin.add(mniAdminMainMenu);

        mniAdminAddAdmin.setText("Add Admin");
        mniAdminAddAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAddAdminActionPerformed(evt);
            }
        });
        mnuAdmin.add(mniAdminAddAdmin);

        mniAdminSearchAdmin.setText("Search Admin");
        mniAdminSearchAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchAdminActionPerformed(evt);
            }
        });
        mnuAdmin.add(mniAdminSearchAdmin);

        mnbAdminMain.add(mnuAdmin);

        mnuDeliveryStaff.setText("Delivery Staff");

        mniAdminAddDS.setText("Add Delivery Staff");
        mniAdminAddDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAddDSActionPerformed(evt);
            }
        });
        mnuDeliveryStaff.add(mniAdminAddDS);

        mniAdminSearchDS.setText("Search Delivery Staff");
        mniAdminSearchDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchDSActionPerformed(evt);
            }
        });
        mnuDeliveryStaff.add(mniAdminSearchDS);

        mniAdminAssignDS.setText("Assign Deliveries");
        mniAdminAssignDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAssignDSActionPerformed(evt);
            }
        });
        mnuDeliveryStaff.add(mniAdminAssignDS);

        mnbAdminMain.add(mnuDeliveryStaff);

        mnuCategory.setText("Category");

        mniAdminAddCategory.setText("Add Category");
        mniAdminAddCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAddCategoryActionPerformed(evt);
            }
        });
        mnuCategory.add(mniAdminAddCategory);

        mniAdminSearchCategory.setText("Search Category");
        mniAdminSearchCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchCategoryActionPerformed(evt);
            }
        });
        mnuCategory.add(mniAdminSearchCategory);

        mnbAdminMain.add(mnuCategory);

        mnuBook.setText("Book");

        mniAdminSearchBook.setText("Search Book");
        mniAdminSearchBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchBookActionPerformed(evt);
            }
        });
        mnuBook.add(mniAdminSearchBook);

        mnbAdminMain.add(mnuBook);

        mnuRecords.setText("Records");

        mniAdminViewCategory.setText("View Categories");
        mniAdminViewCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewCategoryActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewCategory);

        mniAdminViewBook.setText("View Books");
        mniAdminViewBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewBookActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewBook);

        mniAdminViewCustomerOrder.setText("View Customer Orders");
        mniAdminViewCustomerOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewCustomerOrderActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewCustomerOrder);

        mniAdminViewCustomerPayment.setText("View Customer Payments");
        mniAdminViewCustomerPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewCustomerPaymentActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewCustomerPayment);

        mniAdminSearchCustomer.setText("Search Customer");
        mniAdminSearchCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchCustomerActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminSearchCustomer);

        mnbAdminMain.add(mnuRecords);

        setJMenuBar(mnbAdminMain);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHeading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(75, 75, 75)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(lblBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(43, 43, 43)
                                            .addComponent(txtBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblBookCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(cmbBookCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(305, 305, 305)
                                                .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(lblBookPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(43, 43, 43))
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                    .addComponent(lblBookQunatity, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(maskTxtBookPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(txtBookQuantity, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(lblBookID, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(43, 43, 43)
                                            .addComponent(txtBookID, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(lblBookAuthor)
                                .addGap(43, 43, 43)
                                .addComponent(txtBookAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(lblHeading)
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookCategory)
                    .addComponent(cmbBookCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookID)
                    .addComponent(txtBookID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBookTitle))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBookAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBookAuthor))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookPrice)
                    .addComponent(maskTxtBookPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookQunatity)
                    .addComponent(txtBookQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmActionPerformed
        // TODO add your handling code here:
	this.BookDetailsCreator();
    }//GEN-LAST:event_btnConfirmActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
	AdminBookMgmtFrame abmf = new AdminBookMgmtFrame(Username);
	abmf.setVisible(true);
	this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void cmbBookCategoryFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cmbBookCategoryFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_cmbBookCategoryFocusGained

    private void txtBookTitleFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBookTitleFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtBookTitleFocusGained

    private void txtBookAuthorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBookAuthorFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtBookAuthorFocusGained

    private void maskTxtBookPriceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_maskTxtBookPriceFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_maskTxtBookPriceFocusGained

    private void txtBookQuantityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBookQuantityFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtBookQuantityFocusGained

    private void mniAdminAddAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAddAdminActionPerformed
        // TODO add your handling code here:
        AdminAddAdminFrame aaaf = new AdminAddAdminFrame(Username);
        aaaf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAddAdminActionPerformed

    private void mniAdminSearchAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchAdminActionPerformed
        // TODO add your handling code here:
        AdminSearchAdminFrame asaf = new AdminSearchAdminFrame(Username);
        asaf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchAdminActionPerformed

    private void mniAdminAddDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAddDSActionPerformed
        // TODO add your handling code here:
        AdminAddDeliveryStaffFrame aadsf = new AdminAddDeliveryStaffFrame(Username);
        aadsf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAddDSActionPerformed

    private void mniAdminSearchDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchDSActionPerformed
        // TODO add your handling code here:
        AdminSearchDeliveryStaffFrame asdsf = new AdminSearchDeliveryStaffFrame(Username);
        asdsf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchDSActionPerformed

    private void mniAdminAssignDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAssignDSActionPerformed
        // TODO add your handling code here:
        AdminAssignDeliveryStaffFrame aadsf = new AdminAssignDeliveryStaffFrame(Username);
        aadsf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAssignDSActionPerformed

    private void mniAdminAddCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAddCategoryActionPerformed
        // TODO add your handling code here:
        AdminAddCategoryFrame aacf = new AdminAddCategoryFrame(Username);
        aacf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAddCategoryActionPerformed

    private void mniAdminSearchCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchCategoryActionPerformed
        // TODO add your handling code here:
        AdminSearchCategoryFrame ascf = new AdminSearchCategoryFrame(Username);
        ascf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchCategoryActionPerformed

    private void mniAdminSearchBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchBookActionPerformed
        // TODO add your handling code here:
        AdminSearchBookFrame asbf = new AdminSearchBookFrame(Username);
        asbf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchBookActionPerformed

    private void mniAdminViewCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewCategoryActionPerformed
        // TODO add your handling code here:
        AdminViewCategoryFrame avcf = new AdminViewCategoryFrame(Username);
        avcf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewCategoryActionPerformed

    private void mniAdminViewBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewBookActionPerformed
        // TODO add your handling code here:
        AdminViewBookFrame avbf = new AdminViewBookFrame(Username);
        avbf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewBookActionPerformed

    private void mniAdminViewCustomerOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewCustomerOrderActionPerformed
        // TODO add your handling code here:
        AdminViewCustomerOrderFrame avcof = new AdminViewCustomerOrderFrame(Username);
        avcof.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewCustomerOrderActionPerformed

    private void mniAdminViewCustomerPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewCustomerPaymentActionPerformed
        // TODO add your handling code here:
        AdminViewCustomerPaymentFrame avcpf = new AdminViewCustomerPaymentFrame(Username);
        avcpf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewCustomerPaymentActionPerformed

    private void mniAdminSearchCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchCustomerActionPerformed
        // TODO add your handling code here:
        AdminSearchCustomerFrame ascf = new AdminSearchCustomerFrame(Username);
        ascf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchCustomerActionPerformed

    private void mniAdminMainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminMainMenuActionPerformed
        // TODO add your handling code here:
        AdminMainFrame amf = new AdminMainFrame(Username);
        amf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminMainMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminAddBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminAddBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminAddBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminAddBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminAddBookFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnConfirm;
    private javax.swing.JComboBox<String> cmbBookCategory;
    private javax.swing.JLabel lblBookAuthor;
    private javax.swing.JLabel lblBookCategory;
    private javax.swing.JLabel lblBookID;
    private javax.swing.JLabel lblBookPrice;
    private javax.swing.JLabel lblBookQunatity;
    private javax.swing.JLabel lblBookTitle;
    private javax.swing.JLabel lblErrMsg;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JFormattedTextField maskTxtBookPrice;
    private javax.swing.JMenuBar mnbAdminMain;
    private javax.swing.JMenuItem mniAdminAddAdmin;
    private javax.swing.JMenuItem mniAdminAddCategory;
    private javax.swing.JMenuItem mniAdminAddDS;
    private javax.swing.JMenuItem mniAdminAssignDS;
    private javax.swing.JMenuItem mniAdminMainMenu;
    private javax.swing.JMenuItem mniAdminSearchAdmin;
    private javax.swing.JMenuItem mniAdminSearchBook;
    private javax.swing.JMenuItem mniAdminSearchCategory;
    private javax.swing.JMenuItem mniAdminSearchCustomer;
    private javax.swing.JMenuItem mniAdminSearchDS;
    private javax.swing.JMenuItem mniAdminViewBook;
    private javax.swing.JMenuItem mniAdminViewCategory;
    private javax.swing.JMenuItem mniAdminViewCustomerOrder;
    private javax.swing.JMenuItem mniAdminViewCustomerPayment;
    private javax.swing.JMenu mnuAdmin;
    private javax.swing.JMenu mnuBook;
    private javax.swing.JMenu mnuCategory;
    private javax.swing.JMenu mnuDeliveryStaff;
    private javax.swing.JMenu mnuRecords;
    private javax.swing.JTextField txtBookAuthor;
    private javax.swing.JTextField txtBookID;
    private javax.swing.JTextField txtBookQuantity;
    private javax.swing.JTextField txtBookTitle;
    // End of variables declaration//GEN-END:variables
}
