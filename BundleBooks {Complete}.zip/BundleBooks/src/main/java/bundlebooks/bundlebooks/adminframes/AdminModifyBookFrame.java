/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bundlebooks.bundlebooks.adminframes;
import bundlebooks.bundlebooks.classes.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class AdminModifyBookFrame extends javax.swing.JFrame {
    private String Username;
    
    private String SelectedBookID;
    /**
     * Creates new form AdminModifyBookFrame
     */
    public AdminModifyBookFrame() {
        initComponents();
    }
    
    public AdminModifyBookFrame(String username, String selectedBookID) {
        initComponents();
	this.setResizable(false);
	Username = username;
	SelectedBookID = selectedBookID;
	this.DisplayBookDetails();
    }
    
    public void ClearAllTextFields() {
	txtBookID.setText("");
	txtBookTitle.setText("");
	txtBookAuthor.setText("");
	maskTxtBookPrice.setText("");
	txtBookQuantity.setText("");
    }
    
    public final void DisplayBookDetails() {
	CategoryFileHandler cfh = new CategoryFileHandler();
	ArrayList<Category> categoryArrList = cfh.ReadObjectFromCategoryFile();
	for (Category category : categoryArrList) {
	    cmbBookCategory.addItem(category.GetCategoryName());
	}
	
	BookFileHandler bfh = new BookFileHandler();
	ArrayList<Book> bookArrList = bfh.ReadObjectFromBookFile();
	boolean BookExists = false;
	for (Book book : bookArrList) {
	    if (book.GetBookID().equals(SelectedBookID)) {
		String SelectedCategoryID = book.GetCategoryID();
		for (Category category : categoryArrList) {
		    if (SelectedCategoryID.equals(category.GetCategoryID())) {
			cmbBookCategory.setSelectedItem(category.GetCategoryName());
			break;
		    }
		}
		txtBookID.setText(book.GetBookID());
		txtBookTitle.setText(book.GetBookTitle());
		txtBookAuthor.setText(book.GetBookAuthor());
		maskTxtBookPrice.setText(Double.toString(book.GetBookPrice()));
		txtBookQuantity.setText(Integer.toString(book.GetAvailableQuantity()));
		BookExists = true;
		break;
	    }
	}
	if (BookExists == false) {
	    lblErrMsg.setText("Selected book DOES NOT EXIST!");
	}
    }
    
    public void BookDetailsModifier() {
	String SelectedCategoryName = cmbBookCategory.getSelectedItem().toString();
	String DigitOnlyRegex = "\\d+";
	if (txtBookID.getText().trim().equals("")) {
	    lblErrMsg.setText("Book ID is EMPTY");
	} else if (txtBookTitle.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Title is EMPTY");
	} else if (txtBookAuthor.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Author is EMPTY");
	} else if (maskTxtBookPrice.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Price is EMPTY");
	} else if (txtBookQuantity.getText().trim().equals("")) {
	    lblErrMsg.setText("Book Available Quantity is EMPTY");
	} else {
	    try {
		if (!txtBookQuantity.getText().trim().matches(DigitOnlyRegex)) {
		    lblErrMsg.setText("Book Available Quantity is INVALID");
		    txtBookQuantity.setText("");
		} else {
		    CategoryFileHandler cfh = new CategoryFileHandler();
		    ArrayList<Category> categoryArrList = cfh.ReadObjectFromCategoryFile();
		    StringFormatter CapitalFormat = new StringFormatter();
		    String BookCategoryID = "";
		    String BookCategoryName = "";
		    for (Category category : categoryArrList) {
			if (SelectedCategoryName.equals(category.GetCategoryName())) {
			    BookCategoryID = category.GetCategoryID();
			    BookCategoryName = category.GetCategoryName();
			    break;
			}
		    }
		    String BookTitle = CapitalFormat.CapitaliseEachWord(txtBookTitle.getText().trim());
		    String BookAuthor = CapitalFormat.CapitaliseEachWord(txtBookAuthor.getText().trim());
		    double BookPrice = Double.parseDouble(maskTxtBookPrice.getText().trim());
		    int BookQuantity = Integer.parseInt(txtBookQuantity.getText().trim());
		    
		    BookFileHandler bfh = new BookFileHandler();
		    ArrayList<Book> bookArrList = bfh.ReadObjectFromBookFile();
		    boolean DuplicatedBook = false;
		    for (Book book : bookArrList) {
			if (!book.GetBookID().equals(SelectedBookID) && book.GetBookTitle().equals(BookTitle) && book.GetBookAuthor().equals(BookAuthor)) {
			    // Diiferent book IDs with the same title and author
			    lblErrMsg.setText("Book already EXISTS! Please enter a unique book");
			    DuplicatedBook = true;
			    txtBookTitle.setText("");
			    txtBookAuthor.setText("");
			    break;
			}
			// Books with same book ID, same title and author will pass the condition as it is referring to the same book
		    }
		    
		    if (!BookCategoryID.equals("") && !BookCategoryName.equals("") && DuplicatedBook == false) {
			for (Book book : bookArrList) {
			    if (book.GetBookID().equals(SelectedBookID)) {
				book.SetCategoryID(BookCategoryID);
				book.SetCategoryName(BookCategoryName);
				book.SetBookTitle(BookTitle);
				book.SetBookAuthor(BookAuthor);
				book.SetBookPrice(BookPrice);
				book.SetAvailableQuantity(BookQuantity);
				break;
			    }
			}
			bfh.WriteObjectToBookFile(bookArrList);
			lblErrMsg.setText("Book [Title: " + BookTitle + "] has been updated");
			this.ClearAllTextFields();
		    }
		}
	    } catch (NumberFormatException e) {
		System.out.println("ERROR Occured");
	    }
	}
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblHeading = new javax.swing.JLabel();
        lblBookCategory = new javax.swing.JLabel();
        btnConfirm = new javax.swing.JButton();
        lblBookID = new javax.swing.JLabel();
        txtBookID = new javax.swing.JTextField();
        lblBookTitle = new javax.swing.JLabel();
        txtBookTitle = new javax.swing.JTextField();
        btnCancel = new javax.swing.JButton();
        txtBookQuantity = new javax.swing.JTextField();
        lblBookPrice = new javax.swing.JLabel();
        lblErrMsg = new javax.swing.JLabel();
        maskTxtBookPrice = new javax.swing.JFormattedTextField();
        lblBookQunatity = new javax.swing.JLabel();
        cmbBookCategory = new javax.swing.JComboBox<>();
        txtBookAuthor = new javax.swing.JTextField();
        lblBookAuthor = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Book Modifier");

        lblTitle.setFont(new java.awt.Font("Livvic", 1, 24)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Modify Book");
        lblTitle.setMaximumSize(new java.awt.Dimension(150, 31));
        lblTitle.setMinimumSize(new java.awt.Dimension(150, 31));
        lblTitle.setPreferredSize(new java.awt.Dimension(150, 31));

        lblHeading.setFont(new java.awt.Font("Livvic", 1, 18)); // NOI18N
        lblHeading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHeading.setText("Please edit book details");
        lblHeading.setToolTipText("");

        lblBookCategory.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookCategory.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookCategory.setText("Category:");

        btnConfirm.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnConfirm.setText("Confirm");
        btnConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmActionPerformed(evt);
            }
        });

        lblBookID.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookID.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookID.setText("Book ID:");

        txtBookID.setEditable(false);
        txtBookID.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookID.setMargin(new java.awt.Insets(5, 5, 5, 5));

        lblBookTitle.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookTitle.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookTitle.setText("Book Title:");

        txtBookTitle.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookTitle.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtBookTitle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBookTitleFocusGained(evt);
            }
        });

        btnCancel.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        txtBookQuantity.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookQuantity.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtBookQuantity.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBookQuantityFocusGained(evt);
            }
        });

        lblBookPrice.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookPrice.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookPrice.setText("Price RM:");

        lblErrMsg.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N

        maskTxtBookPrice.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0.00"))));
        maskTxtBookPrice.setMargin(new java.awt.Insets(5, 5, 5, 5));
        maskTxtBookPrice.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                maskTxtBookPriceFocusGained(evt);
            }
        });

        lblBookQunatity.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookQunatity.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookQunatity.setText("Quantity:");

        txtBookAuthor.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtBookAuthor.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtBookAuthor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtBookAuthorFocusGained(evt);
            }
        });

        lblBookAuthor.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblBookAuthor.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblBookAuthor.setText("Book Author:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblHeading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(75, 75, 75)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(lblBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(43, 43, 43)
                                            .addComponent(txtBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(lblBookCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(cmbBookCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(305, 305, 305)
                                                .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(lblBookPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(43, 43, 43))
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                    .addComponent(lblBookQunatity, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(maskTxtBookPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(txtBookQuantity, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(lblBookID, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(43, 43, 43)
                                            .addComponent(txtBookID, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addComponent(lblBookAuthor)
                                .addGap(43, 43, 43)
                                .addComponent(txtBookAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(lblHeading)
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookCategory)
                    .addComponent(cmbBookCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookID)
                    .addComponent(txtBookID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBookTitle))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBookAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblBookAuthor))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookPrice)
                    .addComponent(maskTxtBookPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookQunatity)
                    .addComponent(txtBookQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmActionPerformed
        // TODO add your handling code here:
	this.BookDetailsModifier();
    }//GEN-LAST:event_btnConfirmActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
	AdminSearchBookFrame asbf = new AdminSearchBookFrame(Username);
	asbf.setVisible(true);
	this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void txtBookTitleFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBookTitleFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtBookTitleFocusGained

    private void txtBookAuthorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBookAuthorFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtBookAuthorFocusGained

    private void maskTxtBookPriceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_maskTxtBookPriceFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_maskTxtBookPriceFocusGained

    private void txtBookQuantityFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBookQuantityFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtBookQuantityFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminModifyBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminModifyBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminModifyBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminModifyBookFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminModifyBookFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnConfirm;
    private javax.swing.JComboBox<String> cmbBookCategory;
    private javax.swing.JLabel lblBookAuthor;
    private javax.swing.JLabel lblBookCategory;
    private javax.swing.JLabel lblBookID;
    private javax.swing.JLabel lblBookPrice;
    private javax.swing.JLabel lblBookQunatity;
    private javax.swing.JLabel lblBookTitle;
    private javax.swing.JLabel lblErrMsg;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JFormattedTextField maskTxtBookPrice;
    private javax.swing.JTextField txtBookAuthor;
    private javax.swing.JTextField txtBookID;
    private javax.swing.JTextField txtBookQuantity;
    private javax.swing.JTextField txtBookTitle;
    // End of variables declaration//GEN-END:variables
}
