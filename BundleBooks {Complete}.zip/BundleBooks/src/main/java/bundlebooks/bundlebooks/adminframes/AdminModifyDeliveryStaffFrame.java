/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bundlebooks.bundlebooks.adminframes;
import bundlebooks.bundlebooks.classes.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class AdminModifyDeliveryStaffFrame extends javax.swing.JFrame {
    private String Username;
    
    private String SelectedDeliveryStaffUsername;
    /**
     * Creates new form AdminModifyDeliveryStaffFrame
     */
    public AdminModifyDeliveryStaffFrame() {
        initComponents();
    }
    
    public AdminModifyDeliveryStaffFrame(String username, String selectedDeliveryStaffUsername) {
        initComponents();
	this.setResizable(false);
	Username = username;
	SelectedDeliveryStaffUsername = selectedDeliveryStaffUsername;
	this.DisplayDeliveryStaffDetails();
    }
    
    public void ClearAllTextFields() {
	txtDeliveryStaffUsername.setText("");
	txtDeliveryStaffPassword.setText("");
	txtDeliveryStaffConfirmPassword.setText("");
	txtDeliveryStaffName.setText("");
	txtDeliveryStaffEmail.setText("");
	maskTxtDeliveryStaffContact.setText("");
    }
    
    public final void DisplayDeliveryStaffDetails() {
	DeliveryStaffFileHandler dsfh = new DeliveryStaffFileHandler();
	ArrayList<DeliveryStaff> dsArrList = dsfh.ReadObjectFromDSFile();
	boolean DeliveryStaffExists = false;
	for (DeliveryStaff ds : dsArrList) {
	    if (ds.GetUsername().equals(SelectedDeliveryStaffUsername)) {
		txtDeliveryStaffUsername.setText(ds.GetUsername());
		txtDeliveryStaffPassword.setText(ds.GetPassword());
		txtDeliveryStaffConfirmPassword.setText(ds.GetPassword());
		txtDeliveryStaffName.setText(ds.GetName());
		txtDeliveryStaffEmail.setText(ds.GetEmail());
		maskTxtDeliveryStaffContact.setText(ds.GetContact());
		DeliveryStaffExists = true;
		break;
	    }
	}
	if (DeliveryStaffExists == false) {
	    lblErrMsg.setText("Selected delivery staff DOES NOT EXIST!");
	}
    }
    
    public void DeliveryStaffDetailsModifier() {
    if (txtDeliveryStaffUsername.getText().trim().equals("")) {
	    lblErrMsg.setText("Delivery Staff Username is EMPTY");
	} else if (txtDeliveryStaffPassword.getText().trim().equals("")) {
	    lblErrMsg.setText("Delivery Staff Password is EMPTY");
	} else if (txtDeliveryStaffConfirmPassword.getText().trim().equals("")) {
	    lblErrMsg.setText("Delivery Staff Confirm Password is EMPTY");
	} else if (txtDeliveryStaffName.getText().trim().equals("")) {
	    lblErrMsg.setText("Delivery Staff Name is EMPTY");
	} else if (txtDeliveryStaffEmail.getText().trim().equals("")) { 
	    lblErrMsg.setText("Delivery Staff Email is EMPTY");
	} else if (maskTxtDeliveryStaffContact.getText().trim().equals("-")) {
	    lblErrMsg.setText("Delivery Staff Contact is EMPTY");
	} else if (maskTxtDeliveryStaffContact.getText().trim().length() <= 10) {
		lblErrMsg.setText("Delivery Staff Contact is INVALID");
		maskTxtDeliveryStaffContact.setText("");
	} else {
	    StringFormatter sf = new StringFormatter();
	    if (!txtDeliveryStaffPassword.getText().trim().equals(txtDeliveryStaffConfirmPassword.getText().trim())) {
		lblErrMsg.setText("Delivery Staff Passwords DO NOT MATCH!");
		txtDeliveryStaffPassword.setText("");
		txtDeliveryStaffConfirmPassword.setText("");
	    } else if (!sf.IsValidEmail(txtDeliveryStaffEmail.getText().trim())){
		lblErrMsg.setText("Delivery Staff Email is INVALID");
		txtDeliveryStaffEmail.setText("");
	    } else {
		try {
		    String DeliveryStaffUsername = txtDeliveryStaffUsername.getText().trim();
		    String DeliveryStaffPassword = txtDeliveryStaffPassword.getText().trim();
		    String DeliveryStaffName = txtDeliveryStaffName.getText().trim();
		    String DeliveryStaffEmail = txtDeliveryStaffEmail.getText().trim();
		    String DeliveryStaffContact = maskTxtDeliveryStaffContact.getText().trim();
		    
		    AdminFileHandler afh = new AdminFileHandler();
		    DeliveryStaffFileHandler dsfh = new DeliveryStaffFileHandler();
		    CustomerFileHandler cfh = new CustomerFileHandler();
		    ArrayList<Admin> adminArrList = afh.ReadObjectFromAdminFile();
		    ArrayList<DeliveryStaff> dsArrList = dsfh.ReadObjectFromDSFile();
		    ArrayList<Customer> customerArrList = new ArrayList();
		    if (cfh.ReadObjectFromCustomerFile() != null) {
			customerArrList = cfh.ReadObjectFromCustomerFile();
		    }
		    boolean DuplicatedUsername = false;
		    boolean DuplicatedEmail = false;
		    boolean DuplicatedContact = false;
		    for (Admin admin : adminArrList) {
		        if (admin.GetUsername().equals(DeliveryStaffUsername)) {
			    lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
			    DuplicatedUsername = true;
			    txtDeliveryStaffUsername.setText("");
			    break;
		        }
			if (admin.GetEmail().equals(DeliveryStaffEmail)) {
			    lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
			    DuplicatedEmail = true;
			    txtDeliveryStaffEmail.setText("");
			    break;
			}
			if (admin.GetContact().equals(DeliveryStaffContact)) {
			    lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
			    DuplicatedContact = true;
			    maskTxtDeliveryStaffContact.setText("");
			    break;
			}
		    }
		    
		    if (dsArrList != null) {
			for (DeliveryStaff ds : dsArrList) {
			    if (ds.GetUsername().equals(DeliveryStaffUsername) && SelectedDeliveryStaffUsername.equals(DeliveryStaffUsername)){
				// Admin modifying delivery staff accounts, using same username
				break;
			    } else if (ds.GetUsername().equals(DeliveryStaffUsername) && !SelectedDeliveryStaffUsername.equals(DeliveryStaffUsername)) {
				// Admin modifying delivery staff accounts, using new username
				lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
				DuplicatedUsername = true;
				txtDeliveryStaffUsername.setText("");
				break;
			    }
			}
			for (DeliveryStaff ds : dsArrList) {
			    if (ds.GetUsername().equals(SelectedDeliveryStaffUsername) && ds.GetEmail().equals(DeliveryStaffEmail)) {
				// Admin modifying delivery staff accounts, using same email
				break;
			    } else if (!ds.GetUsername().equals(SelectedDeliveryStaffUsername) && ds.GetEmail().equals(DeliveryStaffEmail)) {
				// Admin modifying delivery staff accounts, using new email
				lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
				DuplicatedEmail = true;
				txtDeliveryStaffEmail.setText("");
				break;
			    }
			}
			for (DeliveryStaff ds : dsArrList) {
			    if (ds.GetUsername().equals(SelectedDeliveryStaffUsername) && ds.GetContact().equals(DeliveryStaffContact)) {
				// Admin modifying delivery staff accounts, using same phone number
				break;
			    } else if (!ds.GetUsername().equals(SelectedDeliveryStaffUsername) && ds.GetContact().equals(DeliveryStaffContact)) {
				// Admin modifying delivery staff accounts, using new phone number
				lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
				DuplicatedContact = true;
				maskTxtDeliveryStaffContact.setText("");
				break;
			    }
			}    
		    }
		    
		    if (customerArrList != null) {
			for (Customer customer : customerArrList) {
			    if (customer.getUsername().equals(DeliveryStaffUsername)) {
			        lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
		    		DuplicatedUsername = true;
			        txtDeliveryStaffUsername.setText("");
			        break;
			    }
			    if (customer.getEmail().equals(DeliveryStaffEmail)) {
				lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
			        DuplicatedEmail = true;
				txtDeliveryStaffEmail.setText("");
				break;
			    }
			    if (customer.getContact().equals(DeliveryStaffContact)) {
				lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
				DuplicatedContact = true;
				maskTxtDeliveryStaffContact.setText("");
				break;
			    }
			}
		    }
		    
		    if (DuplicatedUsername == false && DuplicatedEmail == false && DuplicatedContact == false) {
			for (DeliveryStaff ds : dsArrList) {
			    if (ds.GetUsername().equals(SelectedDeliveryStaffUsername)) {
				ds.SetUsername(DeliveryStaffUsername);
				ds.SetPassword(DeliveryStaffPassword);
				ds.SetName(DeliveryStaffName);
				ds.SetEmail(DeliveryStaffEmail);
				ds.SetContact(DeliveryStaffContact);
				break;
			    }
			}
			OrderFileHandler ofh = new OrderFileHandler();
			ArrayList<Order> orderArrList = ofh.ReadObjectFromOrderFile();
			for (Order order : orderArrList) {
			    if (order.GetAssignedDeliveryStaff() != null) {
				if (order.GetAssignedDeliveryStaff().equals(SelectedDeliveryStaffUsername)) {
				    order.SetAssignedDeliveryStaff(DeliveryStaffUsername);
				}
			    }
			}
		        dsfh.WriteObjectToDSFile(dsArrList);
		        lblErrMsg.setText("Delivery Staff [Username: " + DeliveryStaffUsername + "] has been updated" );
		        this.ClearAllTextFields();
		    }
		    
		} catch (Exception e) {
		    System.out.println("ERROR Occured");
		}
	    }
	}
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblHeading = new javax.swing.JLabel();
        txtDeliveryStaffUsername = new javax.swing.JTextField();
        lblDeliveryStaffUsername = new javax.swing.JLabel();
        btnConfirm = new javax.swing.JButton();
        lblDeliveryStaffPassword = new javax.swing.JLabel();
        txtDeliveryStaffPassword = new javax.swing.JTextField();
        lblDeliveryStaffConfirmPassword = new javax.swing.JLabel();
        txtDeliveryStaffConfirmPassword = new javax.swing.JTextField();
        btnCancel = new javax.swing.JButton();
        txtDeliveryStaffName = new javax.swing.JTextField();
        lblDeliveryStaffName = new javax.swing.JLabel();
        lblErrMsg = new javax.swing.JLabel();
        maskTxtDeliveryStaffContact = new javax.swing.JFormattedTextField();
        lblDeliveryStaffContact = new javax.swing.JLabel();
        txtDeliveryStaffEmail = new javax.swing.JTextField();
        lblDeliveryStaffEmail = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Delivery Staff Modifier");

        lblTitle.setFont(new java.awt.Font("Livvic", 1, 24)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Modify Delivery Staff");
        lblTitle.setMaximumSize(new java.awt.Dimension(150, 31));
        lblTitle.setMinimumSize(new java.awt.Dimension(150, 31));
        lblTitle.setPreferredSize(new java.awt.Dimension(150, 31));

        lblHeading.setFont(new java.awt.Font("Livvic", 1, 18)); // NOI18N
        lblHeading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHeading.setText("Please edit delivery staff details");
        lblHeading.setToolTipText("");

        txtDeliveryStaffUsername.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtDeliveryStaffUsername.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtDeliveryStaffUsername.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDeliveryStaffUsernameFocusGained(evt);
            }
        });

        lblDeliveryStaffUsername.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblDeliveryStaffUsername.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblDeliveryStaffUsername.setText("Username:");

        btnConfirm.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnConfirm.setText("Confirm");
        btnConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmActionPerformed(evt);
            }
        });

        lblDeliveryStaffPassword.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblDeliveryStaffPassword.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblDeliveryStaffPassword.setText("Password:");

        txtDeliveryStaffPassword.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtDeliveryStaffPassword.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtDeliveryStaffPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDeliveryStaffPasswordFocusGained(evt);
            }
        });

        lblDeliveryStaffConfirmPassword.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblDeliveryStaffConfirmPassword.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblDeliveryStaffConfirmPassword.setText("<html> Confirm <br> Password: </html>");

        txtDeliveryStaffConfirmPassword.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtDeliveryStaffConfirmPassword.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtDeliveryStaffConfirmPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDeliveryStaffConfirmPasswordFocusGained(evt);
            }
        });

        btnCancel.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        txtDeliveryStaffName.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtDeliveryStaffName.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtDeliveryStaffName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDeliveryStaffNameFocusGained(evt);
            }
        });

        lblDeliveryStaffName.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblDeliveryStaffName.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblDeliveryStaffName.setText("Name:");

        lblErrMsg.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N

        try {
            maskTxtDeliveryStaffContact.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###-#######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        maskTxtDeliveryStaffContact.setMargin(new java.awt.Insets(5, 5, 5, 5));
        maskTxtDeliveryStaffContact.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                maskTxtDeliveryStaffContactFocusGained(evt);
            }
        });

        lblDeliveryStaffContact.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblDeliveryStaffContact.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblDeliveryStaffContact.setText("Contact:");

        txtDeliveryStaffEmail.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtDeliveryStaffEmail.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtDeliveryStaffEmail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtDeliveryStaffEmailFocusGained(evt);
            }
        });

        lblDeliveryStaffEmail.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblDeliveryStaffEmail.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblDeliveryStaffEmail.setText("Email:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHeading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(lblDeliveryStaffConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(43, 43, 43)
                            .addComponent(txtDeliveryStaffConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(lblDeliveryStaffPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(43, 43, 43)
                            .addComponent(txtDeliveryStaffPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblDeliveryStaffUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addComponent(txtDeliveryStaffUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(305, 305, 305)
                                .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblDeliveryStaffName, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(43, 43, 43))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(lblDeliveryStaffContact, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                                        .addComponent(lblDeliveryStaffEmail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(maskTxtDeliveryStaffContact)
                                .addComponent(txtDeliveryStaffName, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                                .addComponent(txtDeliveryStaffEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(lblHeading)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDeliveryStaffUsername)
                    .addComponent(txtDeliveryStaffUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDeliveryStaffPassword)
                    .addComponent(txtDeliveryStaffPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblDeliveryStaffConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDeliveryStaffConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDeliveryStaffName)
                    .addComponent(txtDeliveryStaffName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDeliveryStaffEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDeliveryStaffEmail))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(maskTxtDeliveryStaffContact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDeliveryStaffContact))
                .addGap(30, 30, 30)
                .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmActionPerformed
        // TODO add your handling code here:
	this.DeliveryStaffDetailsModifier();
    }//GEN-LAST:event_btnConfirmActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
	AdminSearchDeliveryStaffFrame asdsf = new AdminSearchDeliveryStaffFrame(Username);
	asdsf.setVisible(true);
	this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void txtDeliveryStaffUsernameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDeliveryStaffUsernameFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtDeliveryStaffUsernameFocusGained

    private void txtDeliveryStaffPasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDeliveryStaffPasswordFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtDeliveryStaffPasswordFocusGained

    private void txtDeliveryStaffConfirmPasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDeliveryStaffConfirmPasswordFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtDeliveryStaffConfirmPasswordFocusGained

    private void txtDeliveryStaffNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDeliveryStaffNameFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtDeliveryStaffNameFocusGained

    private void txtDeliveryStaffEmailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDeliveryStaffEmailFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtDeliveryStaffEmailFocusGained

    private void maskTxtDeliveryStaffContactFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_maskTxtDeliveryStaffContactFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_maskTxtDeliveryStaffContactFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminModifyDeliveryStaffFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminModifyDeliveryStaffFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminModifyDeliveryStaffFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminModifyDeliveryStaffFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminModifyDeliveryStaffFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnConfirm;
    private javax.swing.JLabel lblDeliveryStaffConfirmPassword;
    private javax.swing.JLabel lblDeliveryStaffContact;
    private javax.swing.JLabel lblDeliveryStaffEmail;
    private javax.swing.JLabel lblDeliveryStaffName;
    private javax.swing.JLabel lblDeliveryStaffPassword;
    private javax.swing.JLabel lblDeliveryStaffUsername;
    private javax.swing.JLabel lblErrMsg;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JFormattedTextField maskTxtDeliveryStaffContact;
    private javax.swing.JTextField txtDeliveryStaffConfirmPassword;
    private javax.swing.JTextField txtDeliveryStaffEmail;
    private javax.swing.JTextField txtDeliveryStaffName;
    private javax.swing.JTextField txtDeliveryStaffPassword;
    private javax.swing.JTextField txtDeliveryStaffUsername;
    // End of variables declaration//GEN-END:variables
}
