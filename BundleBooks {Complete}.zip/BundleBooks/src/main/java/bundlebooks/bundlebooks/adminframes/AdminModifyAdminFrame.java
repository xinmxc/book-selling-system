/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bundlebooks.bundlebooks.adminframes;
import bundlebooks.bundlebooks.LoginFrame;
import bundlebooks.bundlebooks.classes.*;
import java.awt.HeadlessException;
import java.util.*;
import javax.swing.*;

/**
 *
 * @author Jason
 */
public class AdminModifyAdminFrame extends javax.swing.JFrame {
    private String Username;
    
    private String SelectedAdminUsername;
    /**
     * Creates new form AdminModifyAdminFrame
     */
    public AdminModifyAdminFrame() {
        initComponents();
    }
    
    public AdminModifyAdminFrame(String username, String selectedAdminUsername) {
        initComponents();
	this.setResizable(false);
	Username = username;
	SelectedAdminUsername = selectedAdminUsername;
	this.DisplayAdminDetails();
    }
    
    public void ClearAllTextFields() {
	txtAdminUsername.setText("");
	txtAdminPassword.setText("");
	txtAdminConfirmPassword.setText("");
	txtAdminName.setText("");
	txtAdminEmail.setText("");
	maskTxtAdminContact.setText("");
    }
    
    public final void DisplayAdminDetails() {
	AdminFileHandler afh = new AdminFileHandler();
	ArrayList<Admin> adminArrList = afh.ReadObjectFromAdminFile();
	boolean AdminExists = false;
	for (Admin admin : adminArrList) {
	    if (admin.GetUsername().equals(SelectedAdminUsername)) {
		txtAdminUsername.setText(admin.GetUsername());
		txtAdminPassword.setText(admin.GetPassword());
		txtAdminConfirmPassword.setText(admin.GetPassword());
		txtAdminName.setText(admin.GetName());
		txtAdminEmail.setText(admin.GetEmail());
		maskTxtAdminContact.setText(admin.GetContact());
		AdminExists = true;
		break;
	    }
	}
	if (AdminExists == false) {
	    lblErrMsg.setText("Selected admin DOES NOT EXIST!");
	}
    }
    
    public void AdminDetailsModifier() {
    if (txtAdminUsername.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Username is EMPTY");
	} else if (txtAdminPassword.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Password is EMPTY");
	} else if (txtAdminConfirmPassword.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Confirm Password is EMPTY");
	} else if (txtAdminName.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Name is EMPTY");
	} else if (txtAdminEmail.getText().trim().equals("")){
	    lblErrMsg.setText("Admin Email is EMPTY");
	} else if (maskTxtAdminContact.getText().trim().equals("-")) {
	    lblErrMsg.setText("Admin Contact is EMPTY");
	} else if (maskTxtAdminContact.getText().trim().length() <= 10) {
		lblErrMsg.setText("Admin Contact is INVALID");
		maskTxtAdminContact.setText("");
	} else {
	    StringFormatter sf = new StringFormatter();
	    if (!txtAdminPassword.getText().trim().equals(txtAdminConfirmPassword.getText().trim())) {
		lblErrMsg.setText("Admin Passwords DO NOT MATCH!");
		txtAdminPassword.setText("");
		txtAdminConfirmPassword.setText("");
	    } else if (!sf.IsValidEmail(txtAdminEmail.getText().trim())){
		lblErrMsg.setText("Admin Email is INVALID");
		txtAdminEmail.setText("");
	    } else {
		try {
		    String AdminUsername = txtAdminUsername.getText().trim();
		    String AdminPassword = txtAdminPassword.getText().trim();
		    String AdminName = txtAdminName.getText().trim();
		    String AdminEmail = txtAdminEmail.getText().trim();
		    String AdminContact = maskTxtAdminContact.getText().trim();
		    
		    AdminFileHandler afh = new AdminFileHandler();
		    DeliveryStaffFileHandler dsfh = new DeliveryStaffFileHandler();
		    CustomerFileHandler cfh = new CustomerFileHandler();
		    ArrayList<Admin> adminArrList = afh.ReadObjectFromAdminFile();
		    ArrayList<DeliveryStaff> dsArrList = new ArrayList();
		    if (dsfh.ReadObjectFromDSFile() != null) {
			dsArrList = dsfh.ReadObjectFromDSFile();
		    }
		    ArrayList<Customer> customerArrList = new ArrayList();
		    if (cfh.ReadObjectFromCustomerFile() != null) {
			customerArrList = cfh.ReadObjectFromCustomerFile();
		    }
		    boolean DuplicatedUsername = false;
		    boolean DuplicatedEmail = false;
		    boolean DuplicatedContact = false;
		    boolean ModifySelfUsername = false;
		    for (Admin admin : adminArrList) {
			// if else block below is sensitive, DO NOT MAKE ANY CHANGES
		        if (admin.GetUsername().equals(AdminUsername) && Username.equals(SelectedAdminUsername)) {
			    // Current admin modifying own account
			    if (SelectedAdminUsername.equals(AdminUsername)) {
				// using same username
				System.out.println("Update own same username successful");
				break;
			    } else {
				// using new username, but duplicated
				lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
				DuplicatedUsername = true;
				txtAdminUsername.setText("");
				break;
			    }
			} else if (admin.GetUsername().equals(AdminUsername) && !Username.equals(SelectedAdminUsername)) {
			    // Current admin modifying other admin accounts
			    if (SelectedAdminUsername.equals(AdminUsername)) {
				// using same username
				System.out.println("Update others same username successful");
				break;
			    } else {
				// using new username, but duplicated
				lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
				DuplicatedUsername = true;
				txtAdminUsername.setText("");
				break;
			    }
			} 
			if (!admin.GetUsername().equals(AdminUsername) && admin.GetUsername().equals(Username)) {
			    if (Username.equals(SelectedAdminUsername)) {
				// Current admin successfully changing their username
				ModifySelfUsername = true;
			    } else {
				// Current admin successfully changing other admins' usernames
			    }
			} else if (admin.GetUsername().equals(AdminUsername)){
			    // final checker for any duplicate username
			    lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
			    DuplicatedUsername = true;
			    txtAdminUsername.setText("");
			    break;
			}
		    }
		    for (Admin admin : adminArrList) {
			if (admin.GetUsername().equals(SelectedAdminUsername) && admin.GetEmail().equals(AdminEmail)) {
			    // Modifying admin accounts, using same email
			    break;
			} else if (!admin.GetUsername().equals(SelectedAdminUsername) && admin.GetEmail().equals(AdminEmail)) {
			    // Modifying admin accounts, using new email
			    lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
			    DuplicatedEmail = true;
			    txtAdminEmail.setText("");
			    break;
			}
		    }
		    for (Admin admin : adminArrList) {
			if (admin.GetUsername().equals(SelectedAdminUsername) && admin.GetContact().equals(AdminContact)) {
			    // Modifying admin accounts, using same phone number
			    break;
			} else if (!admin.GetUsername().equals(SelectedAdminUsername) && admin.GetContact().equals(AdminContact)) {
			    // Modifying admin accounts, using new phone number
			    lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
			    DuplicatedContact = true;
			    maskTxtAdminContact.setText("");
			    break;
			}			
		    }
		    
		    if (dsArrList != null) {
			for (DeliveryStaff ds : dsArrList) {
			    if (ds.GetUsername().equals(AdminUsername)) {
				lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
				DuplicatedUsername = true;
				txtAdminUsername.setText("");
				break;
			    }
			    if (ds.GetEmail().equals(AdminEmail)) {
				lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
				DuplicatedEmail = true;
				txtAdminEmail.setText("");
				break;
			    }
			    if (ds.GetContact().equals(AdminContact)) {
				lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
				DuplicatedContact = true;
				maskTxtAdminContact.setText("");
				break;
			    }
			}
		    }
		    
		    if (customerArrList != null) {
			for (Customer customer : customerArrList) {
			    if (customer.getUsername().equals(AdminUsername)) {
			        lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
		    		DuplicatedUsername = true;
			        txtAdminUsername.setText("");
			        break;
			    }
			    if (customer.getEmail().equals(AdminEmail)) {
				lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
				DuplicatedEmail = true;
				txtAdminEmail.setText("");
				break;
			    }
			    if (customer.getContact().equals(AdminContact)) {
				lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
				DuplicatedContact = true;
				maskTxtAdminContact.setText("");
				break;
			    }
			}
		    }
		    
		    if (DuplicatedUsername == false && DuplicatedEmail == false && DuplicatedContact == false) {
			for (Admin admin : adminArrList) {
			    if (admin.GetUsername().equals(SelectedAdminUsername)) {
				admin.SetUsername(AdminUsername);
				admin.SetPassword(AdminPassword);
				admin.SetName(AdminName);
				admin.SetEmail(AdminEmail);
				admin.SetContact(AdminContact);
				break;
			    }
			}
		        afh.WriteObjectToAdminFile(adminArrList);
		        lblErrMsg.setText("Admin [Username: " + AdminUsername + "] has been updated" );
			this.ClearAllTextFields();
			if (ModifySelfUsername == true) {
			    JOptionPane.showMessageDialog(this, "You have changed your username, please log in again", "Modified Username Log In Prompt", JOptionPane.WARNING_MESSAGE);
			    if (JOptionPane.OK_OPTION == 0) {
				LoginFrame lf = new LoginFrame();
				lf.setVisible(true);
				this.dispose();
			    }
			}
		    }
		    
		} catch (HeadlessException e) {
		    System.out.println("ERROR Occured");
		}
	    }
	}
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblHeading = new javax.swing.JLabel();
        txtAdminUsername = new javax.swing.JTextField();
        lblAdminUsername = new javax.swing.JLabel();
        lblAdminPassword = new javax.swing.JLabel();
        txtAdminPassword = new javax.swing.JTextField();
        txtAdminConfirmPassword = new javax.swing.JTextField();
        lblAdminConfirmPassword = new javax.swing.JLabel();
        lblAdminName = new javax.swing.JLabel();
        txtAdminName = new javax.swing.JTextField();
        lblErrMsg = new javax.swing.JLabel();
        btnCancel = new javax.swing.JButton();
        btnConfirm = new javax.swing.JButton();
        maskTxtAdminContact = new javax.swing.JFormattedTextField();
        lblAdminContact = new javax.swing.JLabel();
        txtAdminEmail = new javax.swing.JTextField();
        lblAdminEmail = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Modifier");

        lblTitle.setFont(new java.awt.Font("Livvic", 1, 24)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Modify Admin");
        lblTitle.setMaximumSize(new java.awt.Dimension(150, 31));
        lblTitle.setMinimumSize(new java.awt.Dimension(150, 31));
        lblTitle.setPreferredSize(new java.awt.Dimension(150, 31));

        lblHeading.setFont(new java.awt.Font("Livvic", 1, 18)); // NOI18N
        lblHeading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHeading.setText("Please edit admin details");
        lblHeading.setToolTipText("");

        txtAdminUsername.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminUsername.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminUsername.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminUsernameFocusGained(evt);
            }
        });

        lblAdminUsername.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminUsername.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminUsername.setText("Username:");

        lblAdminPassword.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminPassword.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminPassword.setText("Password:");

        txtAdminPassword.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminPassword.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminPasswordFocusGained(evt);
            }
        });

        txtAdminConfirmPassword.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminConfirmPassword.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminConfirmPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminConfirmPasswordFocusGained(evt);
            }
        });

        lblAdminConfirmPassword.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminConfirmPassword.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminConfirmPassword.setText("<html> Confirm <br> Password: </html>");

        lblAdminName.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminName.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminName.setText("Name:");

        txtAdminName.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminName.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminNameFocusGained(evt);
            }
        });

        lblErrMsg.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N

        btnCancel.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        btnConfirm.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnConfirm.setText("Confirm");
        btnConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmActionPerformed(evt);
            }
        });

        try {
            maskTxtAdminContact.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###-#######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        maskTxtAdminContact.setMargin(new java.awt.Insets(5, 5, 5, 5));
        maskTxtAdminContact.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                maskTxtAdminContactFocusGained(evt);
            }
        });

        lblAdminContact.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminContact.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminContact.setText("Contact:");

        txtAdminEmail.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminEmail.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminEmail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminEmailFocusGained(evt);
            }
        });

        lblAdminEmail.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminEmail.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminEmail.setText("Email:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(43, 43, 43)
                                    .addComponent(txtAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(43, 43, 43)
                                    .addComponent(txtAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(43, 43, 43)
                                        .addComponent(txtAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(305, 305, 305)
                                        .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblAdminName, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(43, 43, 43)
                                    .addComponent(txtAdminName, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(lblAdminEmail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblAdminContact, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(maskTxtAdminContact, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtAdminEmail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHeading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(lblHeading)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAdminUsername)
                    .addComponent(txtAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAdminPassword)
                    .addComponent(txtAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAdminName)
                    .addComponent(txtAdminName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAdminEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAdminEmail))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(maskTxtAdminContact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAdminContact))
                .addGap(30, 30, 30)
                .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmActionPerformed
        // TODO add your handling code here:
	this.AdminDetailsModifier();
    }//GEN-LAST:event_btnConfirmActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
	AdminSearchAdminFrame asaf = new AdminSearchAdminFrame(Username);
	asaf.setVisible(true);
	this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void txtAdminUsernameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminUsernameFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminUsernameFocusGained

    private void txtAdminPasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminPasswordFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminPasswordFocusGained

    private void txtAdminConfirmPasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminConfirmPasswordFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminConfirmPasswordFocusGained

    private void txtAdminNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminNameFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminNameFocusGained

    private void txtAdminEmailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminEmailFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminEmailFocusGained

    private void maskTxtAdminContactFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_maskTxtAdminContactFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_maskTxtAdminContactFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminModifyAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminModifyAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminModifyAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminModifyAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminModifyAdminFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnConfirm;
    private javax.swing.JLabel lblAdminConfirmPassword;
    private javax.swing.JLabel lblAdminContact;
    private javax.swing.JLabel lblAdminEmail;
    private javax.swing.JLabel lblAdminName;
    private javax.swing.JLabel lblAdminPassword;
    private javax.swing.JLabel lblAdminUsername;
    private javax.swing.JLabel lblErrMsg;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JFormattedTextField maskTxtAdminContact;
    private javax.swing.JTextField txtAdminConfirmPassword;
    private javax.swing.JTextField txtAdminEmail;
    private javax.swing.JTextField txtAdminName;
    private javax.swing.JTextField txtAdminPassword;
    private javax.swing.JTextField txtAdminUsername;
    // End of variables declaration//GEN-END:variables
}
