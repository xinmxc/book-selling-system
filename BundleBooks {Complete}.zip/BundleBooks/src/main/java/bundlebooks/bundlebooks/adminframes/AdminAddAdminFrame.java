/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bundlebooks.bundlebooks.adminframes;
import bundlebooks.bundlebooks.classes.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class AdminAddAdminFrame extends javax.swing.JFrame {
    private String Username;
    /**
     * Creates new form AdminAddAdminFrame
     */
    public AdminAddAdminFrame() {
        initComponents();
    }
    
    public AdminAddAdminFrame(String username) {
	initComponents();
	this.setResizable(false);
	Username = username;
    }
    
    public void ClearAllTextFields() {
	txtAdminUsername.setText("");
	txtAdminPassword.setText("");
	txtAdminConfirmPassword.setText("");
	txtAdminName.setText("");
	txtAdminEmail.setText("");
	maskTxtAdminContact.setText("");
    }
    
    public void AdminDetailsCreator() {
	if (txtAdminUsername.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Username is EMPTY");
	} else if (txtAdminPassword.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Password is EMPTY");
	} else if (txtAdminConfirmPassword.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Confirm Password is EMPTY");
	} else if (txtAdminName.getText().trim().equals("")) {
	    lblErrMsg.setText("Admin Name is EMPTY");
	} else if (txtAdminEmail.getText().trim().equals("")){
	    lblErrMsg.setText("Admin Email is EMPTY");
	} else if (maskTxtAdminContact.getText().trim().equals("-")) {
	    lblErrMsg.setText("Admin Contact is EMPTY");
	} else if (maskTxtAdminContact.getText().trim().length() <= 10) {
		lblErrMsg.setText("Admin Contact is INVALID");
		maskTxtAdminContact.setText("");
	} else {
	    StringFormatter sf = new StringFormatter();
	    if (!txtAdminPassword.getText().trim().equals(txtAdminConfirmPassword.getText().trim())) {
		lblErrMsg.setText("Admin Passwords DO NOT MATCH!");
		txtAdminPassword.setText("");
		txtAdminConfirmPassword.setText("");
	    } else if (!sf.IsValidEmail(txtAdminEmail.getText().trim())){
		lblErrMsg.setText("Admin Email is INVALID");
		txtAdminEmail.setText("");
	    } else {
		try {
		    String AdminUsername = txtAdminUsername.getText().trim();
		    String AdminPassword = txtAdminPassword.getText().trim();
		    String AdminName = txtAdminName.getText().trim();
		    String AdminEmail = txtAdminEmail.getText().trim();
		    String AdminContact = maskTxtAdminContact.getText().trim();
		    
		    // Redundant if block below
		    /*
		    if (adminFile.length() == 0) {
			ArrayList<Admin> adminArrList = new ArrayList<>();
			Admin adminObj = new Admin(AdminUsername, AdminPassword, AdminName, AdminContact);
			adminArrList.add(adminObj);
			this.WriteObjectToAdminFile(adminArrList);
			lblErrMsg.setText("Admin [Username: " + AdminUsername + "] has been created" );
			this.ClearAllTextFields();
		    }
		    */
		    AdminFileHandler afh = new AdminFileHandler();
		    DeliveryStaffFileHandler dsfh = new DeliveryStaffFileHandler();
		    CustomerFileHandler cfh = new CustomerFileHandler();
		    ArrayList<Admin> adminArrList = afh.ReadObjectFromAdminFile();
		    ArrayList<DeliveryStaff> dsArrList = new ArrayList();
		    if (dsfh.ReadObjectFromDSFile() != null) {
			dsArrList = dsfh.ReadObjectFromDSFile();
		    }
		    ArrayList<Customer> customerArrList = new ArrayList();
		    if (cfh.ReadObjectFromCustomerFile() != null) {
			customerArrList = cfh.ReadObjectFromCustomerFile();
		    }
		    boolean DuplicatedUsername = false;
		    boolean DuplicatedEmail = false;
		    boolean DuplicatedContact = false;
		    for (Admin admin : adminArrList) {
		        if (admin.GetUsername().equals(AdminUsername)) {
			    lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
			    DuplicatedUsername = true;
			    txtAdminUsername.setText("");
			    break;
		        }
			if (admin.GetEmail().equals(AdminEmail)) {
			    lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
			    DuplicatedEmail = true;
			    txtAdminEmail.setText("");
			    break;
			}
			if (admin.GetContact().equals(AdminContact)) {
			    lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
			    DuplicatedContact = true;
			    maskTxtAdminContact.setText("");
			    break;
			}
		    }
		    
		    if (dsArrList != null) {
			for (DeliveryStaff ds : dsArrList) {
			    if (ds.GetUsername().equals(AdminUsername)) {
				lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
				DuplicatedUsername = true;
				txtAdminUsername.setText("");
				break;
			    }
			    if (ds.GetEmail().equals(AdminEmail)) {
				lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
				DuplicatedEmail = true;
				txtAdminEmail.setText("");
				break;
			    }
			    if (ds.GetContact().equals(AdminContact)) {
				lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
				DuplicatedContact = true;
				maskTxtAdminContact.setText("");
				break;
			    }
			}
		    }
		    
		    if (customerArrList != null) {
			for (Customer customer : customerArrList) {
			    if (customer.getUsername().equals(AdminUsername)) {
			        lblErrMsg.setText("Username already EXISTS! Please enter a unique username");
		    		DuplicatedUsername = true;
			        txtAdminUsername.setText("");
			        break;
			    }
			    if (customer.getEmail().equals(AdminEmail)) {
				lblErrMsg.setText("Email already EXISTS! Please enter a unique email");
				DuplicatedEmail = true;
				txtAdminEmail.setText("");
				break;
			    }
			    if (customer.getContact().equals(AdminContact)) {
				lblErrMsg.setText("Contact already EXISTS! Please enter a unique phone number");
				DuplicatedContact = true;
				maskTxtAdminContact.setText("");
				break;
			    }
			}
		    }
		    
		    if (DuplicatedUsername == false && DuplicatedEmail == false && DuplicatedContact == false) {
		        Admin adminObj = new Admin(AdminUsername, AdminPassword, AdminName, AdminEmail, AdminContact);
		        adminArrList.add(adminObj);
		        afh.WriteObjectToAdminFile(adminArrList);
		        lblErrMsg.setText("Admin [Username: " + AdminUsername + "] has been created" );
		        this.ClearAllTextFields();
		    }
		    
		} catch (Exception e) {
		    System.out.println("ERROR Occured");
		}
	    }
	}
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        lblHeading = new javax.swing.JLabel();
        txtAdminUsername = new javax.swing.JTextField();
        lblAdminUsername = new javax.swing.JLabel();
        btnConfirm = new javax.swing.JButton();
        lblAdminPassword = new javax.swing.JLabel();
        txtAdminPassword = new javax.swing.JTextField();
        lblAdminConfirmPassword = new javax.swing.JLabel();
        txtAdminConfirmPassword = new javax.swing.JTextField();
        btnCancel = new javax.swing.JButton();
        txtAdminName = new javax.swing.JTextField();
        lblAdminName = new javax.swing.JLabel();
        lblErrMsg = new javax.swing.JLabel();
        maskTxtAdminContact = new javax.swing.JFormattedTextField();
        lblAdminContact = new javax.swing.JLabel();
        txtAdminEmail = new javax.swing.JTextField();
        lblAdminEmail = new javax.swing.JLabel();
        mnbAdminMain = new javax.swing.JMenuBar();
        mnuAdmin = new javax.swing.JMenu();
        mniAdminMainMenu = new javax.swing.JMenuItem();
        mniAdminSearchAdmin = new javax.swing.JMenuItem();
        mnuDeliveryStaff = new javax.swing.JMenu();
        mniAdminAddDS = new javax.swing.JMenuItem();
        mniAdminSearchDS = new javax.swing.JMenuItem();
        mniAdminAssignDS = new javax.swing.JMenuItem();
        mnuCategory = new javax.swing.JMenu();
        mniAdminAddCategory = new javax.swing.JMenuItem();
        mniAdminSearchCategory = new javax.swing.JMenuItem();
        mnuBook = new javax.swing.JMenu();
        mniAdminAddBook = new javax.swing.JMenuItem();
        mniAdminSearchBook = new javax.swing.JMenuItem();
        mnuRecords = new javax.swing.JMenu();
        mniAdminViewCategory = new javax.swing.JMenuItem();
        mniAdminViewBook = new javax.swing.JMenuItem();
        mniAdminViewCustomerOrder = new javax.swing.JMenuItem();
        mniAdminViewCustomerPayment = new javax.swing.JMenuItem();
        mniAdminSearchCustomer = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Creator");

        lblTitle.setFont(new java.awt.Font("Livvic", 1, 24)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Add Admin");
        lblTitle.setMaximumSize(new java.awt.Dimension(150, 31));
        lblTitle.setMinimumSize(new java.awt.Dimension(150, 31));
        lblTitle.setPreferredSize(new java.awt.Dimension(150, 31));

        lblHeading.setFont(new java.awt.Font("Livvic", 1, 18)); // NOI18N
        lblHeading.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHeading.setText("Please enter new admin details");
        lblHeading.setToolTipText("");

        txtAdminUsername.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminUsername.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminUsername.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminUsernameFocusGained(evt);
            }
        });

        lblAdminUsername.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminUsername.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminUsername.setText("Username:");

        btnConfirm.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnConfirm.setText("Confirm");
        btnConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmActionPerformed(evt);
            }
        });

        lblAdminPassword.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminPassword.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminPassword.setText("Password:");

        txtAdminPassword.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminPassword.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminPasswordFocusGained(evt);
            }
        });

        lblAdminConfirmPassword.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminConfirmPassword.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminConfirmPassword.setText("<html> Confirm <br> Password: </html>");

        txtAdminConfirmPassword.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminConfirmPassword.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminConfirmPassword.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminConfirmPasswordFocusGained(evt);
            }
        });

        btnCancel.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        txtAdminName.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminName.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminNameFocusGained(evt);
            }
        });

        lblAdminName.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminName.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminName.setText("Name:");

        lblErrMsg.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N

        try {
            maskTxtAdminContact.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###-#######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        maskTxtAdminContact.setMargin(new java.awt.Insets(5, 5, 5, 5));
        maskTxtAdminContact.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                maskTxtAdminContactFocusGained(evt);
            }
        });

        lblAdminContact.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminContact.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminContact.setText("Contact:");

        txtAdminEmail.setFont(new java.awt.Font("Livvic", 0, 12)); // NOI18N
        txtAdminEmail.setMargin(new java.awt.Insets(5, 5, 5, 5));
        txtAdminEmail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtAdminEmailFocusGained(evt);
            }
        });

        lblAdminEmail.setFont(new java.awt.Font("Livvic", 0, 14)); // NOI18N
        lblAdminEmail.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblAdminEmail.setText("Email:");

        mnuAdmin.setText("Admin");

        mniAdminMainMenu.setText("Main Menu");
        mniAdminMainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminMainMenuActionPerformed(evt);
            }
        });
        mnuAdmin.add(mniAdminMainMenu);

        mniAdminSearchAdmin.setText("Search Admin");
        mniAdminSearchAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchAdminActionPerformed(evt);
            }
        });
        mnuAdmin.add(mniAdminSearchAdmin);

        mnbAdminMain.add(mnuAdmin);

        mnuDeliveryStaff.setText("Delivery Staff");

        mniAdminAddDS.setText("Add Delivery Staff");
        mniAdminAddDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAddDSActionPerformed(evt);
            }
        });
        mnuDeliveryStaff.add(mniAdminAddDS);

        mniAdminSearchDS.setText("Search Delivery Staff");
        mniAdminSearchDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchDSActionPerformed(evt);
            }
        });
        mnuDeliveryStaff.add(mniAdminSearchDS);

        mniAdminAssignDS.setText("Assign Deliveries");
        mniAdminAssignDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAssignDSActionPerformed(evt);
            }
        });
        mnuDeliveryStaff.add(mniAdminAssignDS);

        mnbAdminMain.add(mnuDeliveryStaff);

        mnuCategory.setText("Category");

        mniAdminAddCategory.setText("Add Category");
        mniAdminAddCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAddCategoryActionPerformed(evt);
            }
        });
        mnuCategory.add(mniAdminAddCategory);

        mniAdminSearchCategory.setText("Search Category");
        mniAdminSearchCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchCategoryActionPerformed(evt);
            }
        });
        mnuCategory.add(mniAdminSearchCategory);

        mnbAdminMain.add(mnuCategory);

        mnuBook.setText("Book");

        mniAdminAddBook.setText("Add Book");
        mniAdminAddBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminAddBookActionPerformed(evt);
            }
        });
        mnuBook.add(mniAdminAddBook);

        mniAdminSearchBook.setText("Search Book");
        mniAdminSearchBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchBookActionPerformed(evt);
            }
        });
        mnuBook.add(mniAdminSearchBook);

        mnbAdminMain.add(mnuBook);

        mnuRecords.setText("Records");

        mniAdminViewCategory.setText("View Categories");
        mniAdminViewCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewCategoryActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewCategory);

        mniAdminViewBook.setText("View Books");
        mniAdminViewBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewBookActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewBook);

        mniAdminViewCustomerOrder.setText("View Customer Orders");
        mniAdminViewCustomerOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewCustomerOrderActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewCustomerOrder);

        mniAdminViewCustomerPayment.setText("View Customer Payments");
        mniAdminViewCustomerPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminViewCustomerPaymentActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminViewCustomerPayment);

        mniAdminSearchCustomer.setText("Search Customer");
        mniAdminSearchCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAdminSearchCustomerActionPerformed(evt);
            }
        });
        mnuRecords.add(mniAdminSearchCustomer);

        mnbAdminMain.add(mnuRecords);

        setJMenuBar(mnbAdminMain);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHeading, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(lblAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(43, 43, 43)
                            .addComponent(txtAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(lblAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(43, 43, 43)
                            .addComponent(txtAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addComponent(txtAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(305, 305, 305)
                                .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(lblAdminContact, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(lblAdminName, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                                        .addComponent(lblAdminEmail, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGap(43, 43, 43)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(maskTxtAdminContact)
                                .addComponent(txtAdminName, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                                .addComponent(txtAdminEmail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(lblHeading)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAdminUsername)
                    .addComponent(txtAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAdminPassword)
                    .addComponent(txtAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAdminName)
                    .addComponent(txtAdminName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAdminEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAdminEmail))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(maskTxtAdminContact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAdminContact))
                .addGap(30, 30, 30)
                .addComponent(lblErrMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirm, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmActionPerformed
        // TODO add your handling code here:
	this.AdminDetailsCreator();
    }//GEN-LAST:event_btnConfirmActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:
	AdminAdminMgmtFrame aamf = new AdminAdminMgmtFrame(Username);
	aamf.setVisible(true);
	this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void txtAdminUsernameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminUsernameFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminUsernameFocusGained

    private void txtAdminPasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminPasswordFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminPasswordFocusGained

    private void txtAdminConfirmPasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminConfirmPasswordFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminConfirmPasswordFocusGained

    private void txtAdminNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminNameFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminNameFocusGained

    private void maskTxtAdminContactFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_maskTxtAdminContactFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_maskTxtAdminContactFocusGained

    private void txtAdminEmailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAdminEmailFocusGained
        // TODO add your handling code here:
	lblErrMsg.setText("");
    }//GEN-LAST:event_txtAdminEmailFocusGained

    private void mniAdminSearchAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchAdminActionPerformed
        // TODO add your handling code here:
        AdminSearchAdminFrame asaf = new AdminSearchAdminFrame(Username);
        asaf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchAdminActionPerformed

    private void mniAdminAddDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAddDSActionPerformed
        // TODO add your handling code here:
        AdminAddDeliveryStaffFrame aadsf = new AdminAddDeliveryStaffFrame(Username);
        aadsf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAddDSActionPerformed

    private void mniAdminSearchDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchDSActionPerformed
        // TODO add your handling code here:
        AdminSearchDeliveryStaffFrame asdsf = new AdminSearchDeliveryStaffFrame(Username);
        asdsf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchDSActionPerformed

    private void mniAdminAssignDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAssignDSActionPerformed
        // TODO add your handling code here:
        AdminAssignDeliveryStaffFrame aadsf = new AdminAssignDeliveryStaffFrame(Username);
        aadsf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAssignDSActionPerformed

    private void mniAdminAddCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAddCategoryActionPerformed
        // TODO add your handling code here:
        AdminAddCategoryFrame aacf = new AdminAddCategoryFrame(Username);
        aacf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAddCategoryActionPerformed

    private void mniAdminSearchCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchCategoryActionPerformed
        // TODO add your handling code here:
        AdminSearchCategoryFrame ascf = new AdminSearchCategoryFrame(Username);
        ascf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchCategoryActionPerformed

    private void mniAdminAddBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminAddBookActionPerformed
        // TODO add your handling code here:
        AdminAddBookFrame aabf = new AdminAddBookFrame(Username);
        aabf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminAddBookActionPerformed

    private void mniAdminSearchBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchBookActionPerformed
        // TODO add your handling code here:
        AdminSearchBookFrame asbf = new AdminSearchBookFrame(Username);
        asbf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchBookActionPerformed

    private void mniAdminViewCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewCategoryActionPerformed
        // TODO add your handling code here:
        AdminViewCategoryFrame avcf = new AdminViewCategoryFrame(Username);
        avcf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewCategoryActionPerformed

    private void mniAdminViewBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewBookActionPerformed
        // TODO add your handling code here:
        AdminViewBookFrame avbf = new AdminViewBookFrame(Username);
        avbf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewBookActionPerformed

    private void mniAdminViewCustomerOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewCustomerOrderActionPerformed
        // TODO add your handling code here:
        AdminViewCustomerOrderFrame avcof = new AdminViewCustomerOrderFrame(Username);
        avcof.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewCustomerOrderActionPerformed

    private void mniAdminViewCustomerPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminViewCustomerPaymentActionPerformed
        // TODO add your handling code here:
        AdminViewCustomerPaymentFrame avcpf = new AdminViewCustomerPaymentFrame(Username);
        avcpf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminViewCustomerPaymentActionPerformed

    private void mniAdminSearchCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminSearchCustomerActionPerformed
        // TODO add your handling code here:
        AdminSearchCustomerFrame ascf = new AdminSearchCustomerFrame(Username);
        ascf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminSearchCustomerActionPerformed

    private void mniAdminMainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAdminMainMenuActionPerformed
        // TODO add your handling code here:
        AdminMainFrame amf = new AdminMainFrame(Username);
        amf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_mniAdminMainMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminAddAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminAddAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminAddAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminAddAdminFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminAddAdminFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnConfirm;
    private javax.swing.JLabel lblAdminConfirmPassword;
    private javax.swing.JLabel lblAdminContact;
    private javax.swing.JLabel lblAdminEmail;
    private javax.swing.JLabel lblAdminName;
    private javax.swing.JLabel lblAdminPassword;
    private javax.swing.JLabel lblAdminUsername;
    private javax.swing.JLabel lblErrMsg;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JFormattedTextField maskTxtAdminContact;
    private javax.swing.JMenuBar mnbAdminMain;
    private javax.swing.JMenuItem mniAdminAddBook;
    private javax.swing.JMenuItem mniAdminAddCategory;
    private javax.swing.JMenuItem mniAdminAddDS;
    private javax.swing.JMenuItem mniAdminAssignDS;
    private javax.swing.JMenuItem mniAdminMainMenu;
    private javax.swing.JMenuItem mniAdminSearchAdmin;
    private javax.swing.JMenuItem mniAdminSearchBook;
    private javax.swing.JMenuItem mniAdminSearchCategory;
    private javax.swing.JMenuItem mniAdminSearchCustomer;
    private javax.swing.JMenuItem mniAdminSearchDS;
    private javax.swing.JMenuItem mniAdminViewBook;
    private javax.swing.JMenuItem mniAdminViewCategory;
    private javax.swing.JMenuItem mniAdminViewCustomerOrder;
    private javax.swing.JMenuItem mniAdminViewCustomerPayment;
    private javax.swing.JMenu mnuAdmin;
    private javax.swing.JMenu mnuBook;
    private javax.swing.JMenu mnuCategory;
    private javax.swing.JMenu mnuDeliveryStaff;
    private javax.swing.JMenu mnuRecords;
    private javax.swing.JTextField txtAdminConfirmPassword;
    private javax.swing.JTextField txtAdminEmail;
    private javax.swing.JTextField txtAdminName;
    private javax.swing.JTextField txtAdminPassword;
    private javax.swing.JTextField txtAdminUsername;
    // End of variables declaration//GEN-END:variables
}
