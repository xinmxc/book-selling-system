/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bundlebooks.bundlebooks.customerframes;

import bundlebooks.bundlebooks.classes.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jiaxi
 */
public class CustomerCheckOut extends javax.swing.JFrame {
    private String Username;
    private ArrayList<String> OrderIDArrList;

    public CustomerCheckOut() {
        initComponents();
    }
    
    public CustomerCheckOut(String username)
    {
        initComponents();
        Username = username;
        this.displayCheckOutTable();
    }
    
    public CustomerCheckOut(String username, ArrayList<String> orderID )
    {
        initComponents();
        Username = username;
        OrderIDArrList = orderID;   
        this.displayCheckOutTable();
    }
    
    public final void displayCheckOutTable()
    {    
        OrderFileHandler ofh = new OrderFileHandler();
        BookFileHandler bfh = new BookFileHandler();
        ArrayList<Order> OdrArrList = ofh.ReadObjectFromOrderFile();
        ArrayList<Book> BookArrList = bfh.ReadObjectFromBookFile();
        DefaultTableModel dm = (DefaultTableModel)tblCheckOut.getModel();
        
        dm.setRowCount(0);
        boolean OrderCalculated = false;
        if (!OdrArrList.isEmpty()) {
	    if (OrderIDArrList != null) {
		for(String orderNum : OrderIDArrList )
		{
		    for (Order order : OdrArrList) {
			for (Book book: BookArrList)
			{
			    if (order.GetOrderNum().equals(orderNum) && order.GetCustomerUsername().equals(Username) && book.GetBookID().equals(order.GetBookID()) && !order.GetDatePlaced().equals("null"))
			    { 
				double TotalPrice = book.GetBookPrice()*order.GetBookQuantity();
				order.SetAmount(TotalPrice);
				OrderCalculated = true;
				ofh.WriteObjectToOrderFile(OdrArrList);
			    }
			}
		    }
		} 
	    } else {
                for (Order order : OdrArrList) {
                    for (Book book: BookArrList)
                    {
                        if (order.GetCustomerUsername().equals(Username) && book.GetBookID().equals(order.GetBookID()) && !order.GetDatePlaced().equals("null") && order.GetPaymentDate().equals("null"))
                        { 
                            double TotalPrice = book.GetBookPrice()*order.GetBookQuantity();
                            order.SetAmount(TotalPrice);
                            OrderCalculated = true;
                        }
                    }
                }
            
	    }
             
	}
	if (OrderCalculated != false) {
	    ofh.WriteObjectToOrderFile(OdrArrList);
	}
	
	for (Order order : OdrArrList) {
	    for (Book book : BookArrList) {
		if (order.GetCustomerUsername().equals(Username) && book.GetBookID().equals(order.GetBookID()) && !order.GetDatePlaced().equals("null") && order.GetPaymentDate().equals("null")) {
		    dm.insertRow(dm.getRowCount(), new Object[]{order.GetOrderNum(), order.GetBookID(), book.GetBookTitle(),order.GetBookQuantity(), order.GetAmount(), order.GetDatePlaced()}); 
		}
	    }
	}
    }
    
    public void CancelOrder()
    {
        int SelectedBookIndex = -1;
	DefaultTableModel BookTableModel = (DefaultTableModel) tblCheckOut.getModel();
	SelectedBookIndex = tblCheckOut.getSelectedRow();
	
	if (SelectedBookIndex != -1) {
	    String SelectedOrderID = BookTableModel.getValueAt(SelectedBookIndex, 0).toString();
	    int SelectedOrderBookQuantity = 0;
	    if (Integer.parseInt(BookTableModel.getValueAt(SelectedBookIndex, 3).toString()) > 0) {
		SelectedOrderBookQuantity = Integer.parseInt(BookTableModel.getValueAt(SelectedBookIndex, 3).toString());
	    }
            OrderFileHandler ofh = new OrderFileHandler();
	    BookFileHandler bfh = new BookFileHandler();
            ArrayList<Order> orderArrList = ofh.ReadObjectFromOrderFile();
	    ArrayList<Book> BookArrList = bfh.ReadObjectFromBookFile();
            boolean DeleteCartOrder = false;
            for (Order order : orderArrList) { 
		for (Book book : BookArrList) {
		    if (order.GetOrderNum().equals(SelectedOrderID) && book.GetBookID().equals(order.GetBookID())) {
			book.SetAvailableQuantity(book.GetAvailableQuantity() + SelectedOrderBookQuantity);
		    }
		}
                if (order.GetOrderNum().equals(SelectedOrderID))
                {
                    orderArrList.remove(order);
                    DeleteCartOrder = true;
                    break;
                }  
	    }
            if (DeleteCartOrder == true)
            {
                ofh.WriteObjectToOrderFile(orderArrList);
		bfh.WriteObjectToBookFile(BookArrList);
                this.displayCheckOutTable();
            } 
	} else 
        {
	    JOptionPane.showMessageDialog(this, "Please select an item!");   
	}
    }
    
    
    
    public void displayCheckOutPrice()
    {
        StringFormatter sf = new StringFormatter();
        double totalPrice = 0;
        for(int i = 0; i < tblCheckOut.getRowCount(); i++)
        {
            
            totalPrice = totalPrice + Double.parseDouble(tblCheckOut.getValueAt(i, 4).toString());
        }
        lbltotalAmount.setText("Total Amount : " + sf.CurrencyFormatter(totalPrice));
    }
    
    public void setDateToNull()
    {
        DefaultTableModel BookTableModel = (DefaultTableModel) tblCheckOut.getModel();
        OrderFileHandler ofh = new OrderFileHandler();
        ArrayList<Order> OrderArrList = ofh.ReadObjectFromOrderFile();
	
        int[] SelectedOrderIndexes = tblCheckOut.getSelectedRows();
        ArrayList<String> SelectedOrderNumberArrList = new ArrayList();
        for (int i : SelectedOrderIndexes)
        {
            String selectedOrderNum = BookTableModel.getValueAt(i, 0).toString();    
            SelectedOrderNumberArrList.add(selectedOrderNum);
        }
        boolean CancelledOrder = false;
        for(String orderNum : SelectedOrderNumberArrList)
        {
            for(Order order : OrderArrList)
            {
                if(order.GetCustomerUsername().equals(Username) && order.GetOrderNum().equals(orderNum)){
                    order.SetDatePlaced(null);
                    CancelledOrder = true;
                    break;
                }     
            }  
        }
	if (CancelledOrder != false) {
	    ofh.WriteObjectToOrderFile(OrderArrList);
	}
	this.displayCheckOutTable();
	this.displayCheckOutPrice();
    }
    
    public void setPaymentDate()
    {
        LocalDateTime now = LocalDateTime.now();
        DefaultTableModel BookTableModel = (DefaultTableModel) tblCheckOut.getModel();
        OrderFileHandler ofh = new OrderFileHandler();
        ArrayList<Order> OrderArrList = ofh.ReadObjectFromOrderFile();
        int numrow = tblCheckOut.getRowCount();
        ArrayList<String> SelectedOrderNumberArrList = new ArrayList();
        for(int i = 0; i < numrow; i++)
        {
            String selectedOrderNum = BookTableModel.getValueAt(i, 0).toString();    
            SelectedOrderNumberArrList.add(selectedOrderNum);
        }
        boolean setDateSuccessful = false;
        for(String orderNum : SelectedOrderNumberArrList)
        {
            for(Order order:OrderArrList)
            {
                if(order.GetCustomerUsername().equals(Username) && order.GetOrderNum().equals(orderNum)){
                    order.SetPaymentDate(now);
                    setDateSuccessful = true;
                    break;
                }     
            }  
        }
        if (setDateSuccessful != false)
        {
            ofh.WriteObjectToOrderFile(OrderArrList);
            JOptionPane.showMessageDialog(this, "Check out successful!");
        }
          
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCheckOut = new javax.swing.JTable();
        btnCheckOut = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        lbltotalAmount = new javax.swing.JLabel();
        btnCancelOrder = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 153, 153));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Check Out");

        tblCheckOut.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "OrderID", "BookID", "BookTitle", "BookQuantity", "Total Book Price", "Order DateTime"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblCheckOut.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jScrollPane1.setViewportView(tblCheckOut);

        btnCheckOut.setText("Check Out");
        btnCheckOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCheckOutActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        lbltotalAmount.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lbltotalAmount.setForeground(new java.awt.Color(0, 0, 0));
        lbltotalAmount.setText("Total Amount: ");

        btnCancelOrder.setText("Cancel Order");
        btnCancelOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelOrderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(106, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(219, 219, 219))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnCheckOut, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnCancelOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(130, 130, 130)
                                .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 596, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbltotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(87, 87, 87))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addGap(38, 38, 38)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbltotalAmount)
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCheckOut, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        CustomerMainFrame cmf = new CustomerMainFrame(Username);
	cmf.setVisible(true);
	this.dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnCheckOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCheckOutActionPerformed
        this.displayCheckOutPrice();
        this.setPaymentDate();
        CustomerMainFrame cmf = new CustomerMainFrame(Username);
        cmf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnCheckOutActionPerformed

    private void btnCancelOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelOrderActionPerformed

	this.CancelOrder();
    }//GEN-LAST:event_btnCancelOrderActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerCheckOut.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerCheckOut.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerCheckOut.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerCheckOut.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerCheckOut().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnCancelOrder;
    private javax.swing.JButton btnCheckOut;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbltotalAmount;
    public javax.swing.JTable tblCheckOut;
    // End of variables declaration//GEN-END:variables
}
