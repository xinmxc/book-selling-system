/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bundlebooks.bundlebooks.customerframes;

import bundlebooks.bundlebooks.classes.*;
import java.time.LocalDateTime;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jiaxi
 */
public class CustomerViewCart extends javax.swing.JFrame {
    private String Username;

    public CustomerViewCart() {
        initComponents();
    }

    public CustomerViewCart(String username)
    {
        initComponents();
        Username = username;
        this.displayItem();
        SpnQuantity.setValue(1);
    }
    
    public final void displayItem()
    {
        OrderFileHandler ofh = new OrderFileHandler();
        BookFileHandler bfh = new BookFileHandler();
        ArrayList<Order> OdrArrList = ofh.ReadObjectFromOrderFile();
        ArrayList<Book> BookArrList = bfh.ReadObjectFromBookFile();
        DefaultTableModel dm = (DefaultTableModel)tblItem.getModel();
        dm.setRowCount(0);
        if (!OdrArrList.isEmpty()) {
	    for (Order order : OdrArrList) {
                for(Book book : BookArrList)
                {
                    if (order.GetCustomerUsername().equals(Username) && book.GetBookID().equals(order.GetBookID()) && order.GetDatePlaced().equals("null") && order.GetPaymentDate().equals("null"))
                    {
                        dm.insertRow(dm.getRowCount(), new Object[]{order.GetOrderNum(), book.GetBookTitle(), book.GetBookPrice(), order.GetBookQuantity()}); 
                    }
                }
	    }
	}     
    }

    public void PlaceOrder()
    {
        int getSelectedRow = -1;
        DefaultTableModel BookTableModel = (DefaultTableModel) tblItem.getModel();
        int indexs[]=tblItem.getSelectedRows();
        getSelectedRow = tblItem.getSelectedRow();
        LocalDateTime now = LocalDateTime.now();
        ArrayList<String> SelectedOrderNumberArrList = new ArrayList();
	
        if(getSelectedRow != -1)
        {
            for(int i : indexs)
            {
                String selectedOrderNum = BookTableModel.getValueAt(i, 0).toString();    
                SelectedOrderNumberArrList.add(selectedOrderNum);
            }
            try
            {
                OrderFileHandler ofh = new OrderFileHandler();
                ArrayList<Order> OrderArrList = ofh.ReadObjectFromOrderFile();
                for(String orderNum : SelectedOrderNumberArrList)
                {
                    for(Order order:OrderArrList)
                    {
                        if(order.GetOrderNum().equals(orderNum)){
                            order.SetDatePlaced(now);
                            ofh.WriteObjectToOrderFile(OrderArrList);
                            break;
                        }     
                    }  
                }   
                CustomerCheckOut ccp = new CustomerCheckOut(Username,SelectedOrderNumberArrList);
                ccp.setVisible(true);
                this.dispose();   
            } catch(Exception e)
            {
                System.out.println("order ERROR Occured");
            }
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Please select an option!");
        }
    }
    
    public void setQuantity()
    {
        int getSelectedRow = -1;
        DefaultTableModel BookTableModel = (DefaultTableModel) tblItem.getModel();
        getSelectedRow = tblItem.getSelectedRow();
        LocalDateTime now = LocalDateTime.now();
        if(getSelectedRow != -1)
        {
            String selectedOrderNum = BookTableModel.getValueAt(getSelectedRow, 0).toString();
            try
            {
                boolean selectQuantity = false;
                OrderFileHandler ofh = new OrderFileHandler();
                ArrayList<Order> OrderArrList = ofh.ReadObjectFromOrderFile();
                BookFileHandler bfh = new BookFileHandler();
                ArrayList<Book> BookArrList = bfh.ReadObjectFromBookFile();
                int quantity = (Integer)SpnQuantity.getValue();
                for(Order order:OrderArrList)
                {
                    for(Book book: BookArrList)
                    { 
                        if(order.GetCustomerUsername().equals(Username) && order.GetOrderNum().equals(selectedOrderNum) && order.GetBookID().equals(book.GetBookID())){      
                            if(quantity <= book.GetAvailableQuantity())
                            {
				// if the cart order has a book quantity of 0
				if (order.GetBookQuantity() == 0) {
				    System.out.println("try order");
				    System.out.println(book.GetAvailableQuantity()+"-"+quantity+"="+ (book.GetAvailableQuantity() - quantity));
				    order.SetBookQuantity(quantity); 
                                
				    ofh.WriteObjectToOrderFile(OrderArrList);
				    int availableStock = book.GetAvailableQuantity() - quantity;
				    book.SetAvailableQuantity(availableStock);
				    bfh.WriteObjectToBookFile(BookArrList);
				    SpnQuantity.setValue(1);
				} else {
				    if (quantity > order.GetBookQuantity()) {
					// if the cart order has a book quantity more than 0, but less than the new quantity that the customer wants
					int additionalQuantityToSubtract = quantity - order.GetBookQuantity();
					book.SetAvailableQuantity(book.GetAvailableQuantity() - additionalQuantityToSubtract);
					order.SetBookQuantity(quantity);
					ofh.WriteObjectToOrderFile(OrderArrList);
					bfh.WriteObjectToBookFile(BookArrList);
				    } else {
					// if the cart order has a book quantity more than 0, but more than the new quantity that the customer wants
					int additionalQuantityToAdd = order.GetBookQuantity() - quantity;
					book.SetAvailableQuantity(book.GetAvailableQuantity() + additionalQuantityToAdd);
					order.SetBookQuantity(quantity);
					ofh.WriteObjectToOrderFile(OrderArrList);
					bfh.WriteObjectToBookFile(BookArrList);
				    }
				}
                            } else if (quantity > book.GetAvailableQuantity())
                            {
                                JOptionPane.showMessageDialog(this, "Insufficient stock!");
                            }
                        }
                    }         
		}
                
                this.displayItem();
                
            } catch(Exception e)
            {
            System.out.println("order ERROR Occured");
            }
            
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Please select an item");
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        SpnQuantity = new javax.swing.JSpinner();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();
        btnBackToMenu = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblItem = new javax.swing.JTable();
        btnProceed = new javax.swing.JButton();
        btnAddQuantity = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 153, 153));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("View Cart");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Quantity");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Order list");

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnBackToMenu.setText("Back to Menu");
        btnBackToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenuActionPerformed(evt);
            }
        });

        tblItem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order ID", "Book Title", "Book Price", "Book Quantity"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblItem.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblItem.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        jScrollPane2.setViewportView(tblItem);

        btnProceed.setText("Proceed");
        btnProceed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProceedActionPerformed(evt);
            }
        });

        btnAddQuantity.setText("Add quantity");
        btnAddQuantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddQuantityActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Ctrl+click for multiple selection");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(392, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(228, 228, 228))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(197, 197, 197)
                        .addComponent(btnAddQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 592, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnProceed, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SpnQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnBackToMenu)))
                .addGap(28, 28, 28))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(btnBackToMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SpnQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProceed, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int SelectedBookIndex = -1;
	DefaultTableModel BookTableModel = (DefaultTableModel) tblItem.getModel();
	SelectedBookIndex = tblItem.getSelectedRow();
	
	if (SelectedBookIndex != -1) {
	    String SelectedOrderID = BookTableModel.getValueAt(SelectedBookIndex, 0).toString();
	    int SelectedOrderBookQuantity = 0;
	    if (Integer.parseInt(BookTableModel.getValueAt(SelectedBookIndex, 3).toString()) > 0) {
		SelectedOrderBookQuantity = Integer.parseInt(BookTableModel.getValueAt(SelectedBookIndex, 3).toString());
	    }
            OrderFileHandler ofh = new OrderFileHandler();
	    BookFileHandler bfh = new BookFileHandler();
            ArrayList<Order> orderArrList = ofh.ReadObjectFromOrderFile();
	    ArrayList<Book> BookArrList = bfh.ReadObjectFromBookFile();
            boolean DeleteCartOrder = false;
            for (Order order : orderArrList) { 
		for (Book book : BookArrList) {
		    if (order.GetOrderNum().equals(SelectedOrderID) && book.GetBookID().equals(order.GetBookID())) {
			book.SetAvailableQuantity(book.GetAvailableQuantity() + SelectedOrderBookQuantity);
		    }
		}
                if (order.GetOrderNum().equals(SelectedOrderID))
                {
                    orderArrList.remove(order);
                    DeleteCartOrder = true;
                    break;
                }  
	    }
            if (DeleteCartOrder == true)
            {
                ofh.WriteObjectToOrderFile(orderArrList);
		bfh.WriteObjectToBookFile(BookArrList);
                this.displayItem();
            } 
	} else 
        {
	    JOptionPane.showMessageDialog(this, "Please select an item!");   
	}
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnBackToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenuActionPerformed
        CustomerMainFrame cmf = new CustomerMainFrame(Username);
        cmf.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnBackToMenuActionPerformed

    private void btnProceedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProceedActionPerformed
        this.PlaceOrder();
        this.displayItem();
    }//GEN-LAST:event_btnProceedActionPerformed

    private void btnAddQuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddQuantityActionPerformed
        this.setQuantity();
    }//GEN-LAST:event_btnAddQuantityActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerViewCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerViewCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerViewCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerViewCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerViewCart().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner SpnQuantity;
    private javax.swing.JButton btnAddQuantity;
    private javax.swing.JButton btnBackToMenu;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnProceed;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    public javax.swing.JTable tblItem;
    // End of variables declaration//GEN-END:variables
}
