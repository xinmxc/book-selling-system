/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
/**
 *
 * @author Jason
 */
public class Book extends Category implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String BookID;
    
    public String GetBookID() {
	return BookID;
    }
    
    private String BookTitle;
    
    public String GetBookTitle() {
	return BookTitle;
    }
    
    public void SetBookTitle(String bookTitle) {
	BookTitle = bookTitle;
    }
    
    private String BookAuthor;
    
    public String GetBookAuthor() {
	return BookAuthor;
    }
    
    public void SetBookAuthor(String bookAuthor) {
	BookAuthor = bookAuthor;
    }
    
    private double BookPrice; // book price per unit
    
    public double GetBookPrice() {
	return Math.round(BookPrice * 100.0)/100.0;
    }
    
    public void SetBookPrice(double bookPrice) {
	BookPrice = bookPrice;
    }
    
    private int AvailableQuantity; // this is the book's available quantity in the store
    
    public int GetAvailableQuantity() {
	return AvailableQuantity;
    }
    
    public void SetAvailableQuantity(int quantity) {
	AvailableQuantity = quantity;
    }

    public Book(String categoryID, String category, String bookID, String bookTitle, String bookAuthor, double bookPrice, int availableQuantity) {
	super(categoryID, category);
	BookID = bookID;
	BookTitle = bookTitle;
	BookAuthor = bookAuthor;
	BookPrice = bookPrice;
	AvailableQuantity = availableQuantity;
    }
}
