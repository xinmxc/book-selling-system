/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;

/**
 *
 * @author Jason
 */
public class Staff implements Serializable {
    private static final long serialVersionUID = 1L;
    
    protected String Username;
    
    public String GetUsername() {
	return Username;
    }
    
    public void SetUsername(String username) {
	Username = username;
    }

    protected String Password;
    
    public String GetPassword() {
	return Password;
    }
    
    public void SetPassword(String password) {
	Password = password;
    }
    
    protected String Name;
    
    public String GetName() {
	return Name;
    }
    
    public void SetName(String name) {
	Name = name;
    }
    
    protected String Email;
    
    public String GetEmail() {
	return Email;
    }
    
    public void SetEmail(String email) {
	Email = email;
    }
    
    protected String Contact;
    
    public String GetContact() {
	return Contact;
    }
    
    public void SetContact(String contact) {
	Contact = contact;
    }
    
    public Staff(String username, String password, String name, String email, String contact) {
	Username = username;
	Password = password;
	Name = name;
	Email = email;
	Contact = contact;
    }
}
