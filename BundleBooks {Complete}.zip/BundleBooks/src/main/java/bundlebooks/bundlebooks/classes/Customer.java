/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
/**
 *
 * @author jiaxi
 */
public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;
    private String Username, Name, Email, Contact, Password;
    private String address;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getContact() {
        return Contact;
    }

    public void setContact(String Contact) {
        this.Contact = Contact;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    
    public Customer(String u, String n, String e, String c, String p)
    {
        Username = u;
        Name = n;
        Email = e;
        Contact = c;
        Password = p;
    }
    
    public Customer(String u, String n, String e, String c, String p, String a)
    {
        Username = u;
        Name = n;
        Email = e;
        Contact = c;
        Password = p;
        address = a;
    }
}
