/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class CategoryFileHandler {
    private static final String CategoryFilePath = "C:\\Users\\Jason\\Documents\\APU\\Sem 3\\Object Oriented Development for Java\\Group Assignment\\BundleBooks\\Category.txt";
    
    public ArrayList<Category> ReadObjectFromCategoryFile() {
	try {
	    FileInputStream fileInput = new FileInputStream(CategoryFilePath);
	    ObjectInputStream objInput = new ObjectInputStream(fileInput);
	    ArrayList<Category> categoryArrList = (ArrayList<Category>) objInput.readObject();
	    return categoryArrList;
	} catch (IOException | ClassNotFoundException e) {
	    System.out.println("Category.txt file DOES NOT EXIST!");
	    return null;
	}
    }
    
    public void WriteObjectToCategoryFile(ArrayList<Category> arrList) {
	try {
	    FileOutputStream fileOutput = new FileOutputStream(CategoryFilePath);
	    ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
	    objOutput.writeObject(arrList);
	} catch (IOException e) {
	    System.out.println("ERROR Occured");
	}
    }
}
