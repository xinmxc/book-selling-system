/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;

/**
 *
 * @author Jason
 */
public class CategoryIDFormatter {
    public final String CategoryIDFormatter(int id) {
	String formattedCategoryID = String.format("%04d", id);
	String categoryIdentifier = "CT";
	String fullCategoryID = categoryIdentifier + formattedCategoryID;
	return fullCategoryID;
    }
}


