/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
import java.time.*;
import java.time.format.*;

/**
 *
 * @author Jason
 */
public class Order implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String OrderNum;
    
    public String GetOrderNum() {
	return OrderNum;
    }
    
    private String CustomerUsername;
    
    public String GetCustomerUsername() {
	return CustomerUsername;
    }
    
    public void SetCustomerUsername(String customerUsername) {
	CustomerUsername = customerUsername;
    }
    
    private String BookID;
    
    public String GetBookID() {
	return BookID;
    }
    
    public void SetBookID(String bookID) {
	BookID = bookID;
    }
    
    private int BookQuantity;
    
    public int GetBookQuantity() {
	return BookQuantity;
    }
    
    public void SetBookQuantity(int bookQuantity) {
	BookQuantity = bookQuantity;
    }
    
    private double Amount; // for customer payment frame
    
    public double GetAmount() {
	return Math.round(Amount * 100.0)/100.0;
    }
    
    public void SetAmount(double amount) {
	Amount = amount;
    }
    
    private LocalDateTime DatePlaced; // stores the date of the order placement
    
    public String GetDatePlaced() {
	DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	if (DatePlaced != null) {
	    return DatePlaced.format(dateFormat);
	} else {
	    return "null";
	}
    }
    
    public void SetDatePlaced(LocalDateTime datePlaced) {
	DatePlaced = datePlaced;
    }
    
    private LocalDateTime PaymentDate; // stores the date of payment by the customer
    
    public String GetPaymentDate() {
	DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	if (PaymentDate != null) {
	    return PaymentDate.format(dateFormat);
	} else {
	    return "null";
	}
    }
    
    public void SetPaymentDate(LocalDateTime paymentDate) {
	PaymentDate = paymentDate;
    }
    
    private LocalDateTime DateDelivered; // should be null when it has not been delivered
    
    public String GetDateDelivered() {
	DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	if (DateDelivered != null) {
	    return DateDelivered.format(dateFormat);
	} else {
	    return "null";
	}
    }
    
    public void SetDateDelivered(LocalDateTime dateDelivered) {
	DateDelivered = dateDelivered;
    }
    
    private String AssignedDeliveryStaff; // Delivery Staff username
    
    public String GetAssignedDeliveryStaff() {
	return AssignedDeliveryStaff;
    }
    
    public void SetAssignedDeliveryStaff(String deliveryStaffUsername) {
	AssignedDeliveryStaff = deliveryStaffUsername;
    }
    
    public boolean InDeliveryStatus; // The delivery status of an order after the delivery staff has selected for delivery
    
    public String GetInDeliveryStatus() {
	if (InDeliveryStatus == true && this.GetDateDelivered().equals("null")) {
	    return "In Delivery";
	} else if (InDeliveryStatus == true && !this.GetDateDelivered().equals("null")){
	    return "Delivered";
	} else {
	    return "Not Delivered";
	}
    }
    
    public void SetInDeliveryStatus(boolean inDeliveryStatus) {
	InDeliveryStatus = inDeliveryStatus;
    }
    
    public String OrderFeedback; // Order feedback by delivery staff
    
    public String GetOrderFeedback() {
	return OrderFeedback;
    }
    
    public void SetOrderFeedback(String orderFeedback) {
	OrderFeedback = orderFeedback;
    }
    
    // Constructor for creating an order in cart
    public Order(String orderNum, String customerUsername, String bookID, double amount, int bookQuantity) {
	OrderNum = orderNum;
	CustomerUsername = customerUsername;
	BookID = bookID;
	Amount = amount;
	BookQuantity = bookQuantity;
    }
    
    // Overloaded constructor for creating a placed order
    public Order(String orderNum, String customerUsername, String bookID, int bookQuantity, double amount, LocalDateTime datePlaced) {
	OrderNum = orderNum;
	CustomerUsername = customerUsername;
	BookID = bookID;
	BookQuantity = bookQuantity;
	Amount = amount;
	DatePlaced = datePlaced;
    }
    /*
    Tester code for LocalDateTime Get-Set Methods
    public static void main(String[] args) {
	Order orderObj = new Order("1111", "love", "BK23", 2,39.30, LocalDateTime.now());
	System.out.println(orderObj.GetDatePlaced());
    }
    */
}
