/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
/**
 *
 * @author Jason
 */
public class Category implements Serializable{
    private static final long serialVersionUID = 1L;
    
    protected String CategoryID;
    
    public String GetCategoryID() {
	return CategoryID;
    }
    
    public void SetCategoryID(String categoryID) {
	CategoryID = categoryID;
    }
    
    protected String CategoryName;
    
    public String GetCategoryName() {
	return CategoryName;
    }
    
    public void SetCategoryName(String category) {
	CategoryName = category;
    }
    
    public Category(String categoryID, String category) {
	CategoryID = categoryID;
	CategoryName = category;
    }
}
