/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class BookFileHandler {
    private static final String BookFilePath = "C:\\Users\\Jason\\Documents\\APU\\Sem 3\\Object Oriented Development for Java\\Group Assignment\\BundleBooks\\Book.txt";
    
    public ArrayList<Book> ReadObjectFromBookFile() {
	try {
	    FileInputStream fileInput = new FileInputStream(BookFilePath);
	    ObjectInputStream objInput = new ObjectInputStream(fileInput);
	    ArrayList<Book> bookArrList = (ArrayList<Book>) objInput.readObject();
	    return bookArrList;
	} catch (IOException | ClassNotFoundException e) {
	    System.out.println("Book.txt file DOES NOT EXIST!");
	    return null;
	}
    }
    
    public void WriteObjectToBookFile(ArrayList<Book> arrList) {
	try {
	    FileOutputStream fileOutput = new FileOutputStream(BookFilePath);
	    ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
	    objOutput.writeObject(arrList);
	} catch (IOException e) {
	    System.out.println("ERROR Occured");
	}
    }
}
