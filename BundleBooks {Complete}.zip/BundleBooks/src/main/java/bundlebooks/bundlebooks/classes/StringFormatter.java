/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.util.regex.*;
import java.text.*;
/**
 *
 * @author Jason
 */
public class StringFormatter {
    public String CapitaliseEachWord(String str) {
	String CapitalisedWord = "";
	if (str.contains("-")) {
	    String replacedStr = str.replace("-", "`");
	    String userWordArr[] = replacedStr.split("\\s");
	    String CapitalisedWordCont = "";
	    for (String word : userWordArr) {
		if (word.contains("`")) {
		    String CapitalisedSubWordCont = "";
		    String replacedSubStr = word.replace("`", " ");
		    String subUserWordArr[] = replacedSubStr.split("\\s");
		    for (String subWord : subUserWordArr) {
			String subFirstLetter = subWord.substring(0, 1);
			String subRestOfWord = subWord.substring(1);
			CapitalisedSubWordCont += subFirstLetter.toUpperCase() + subRestOfWord + " ";
		    }
		    CapitalisedWordCont += CapitalisedSubWordCont.trim().replace(" ", "`") + " ";
		} else {
		    String firstLetter = word.substring(0,1);
		    String restOfWord = word.substring(1);
		    CapitalisedWordCont += firstLetter.toUpperCase() + restOfWord + " ";
		}
	    }
	    CapitalisedWord = CapitalisedWordCont.trim().replace("`", "-");
	} else {
	    String userWordArr[] = str.split("\\s");
	    for (String word : userWordArr) {
		String firstLetter = word.substring(0,1);
		String restOfWord = word.substring(1);
		CapitalisedWord += firstLetter.toUpperCase() + restOfWord + " ";
	    }
	}
	return CapitalisedWord.trim();
    }
    
    public boolean IsValidEmail(String email) {
	String EmailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                            "[a-zA-Z0-9_+&*-]+)*@" +
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                            "A-Z]{2,7}$";
	Pattern EmailPattern = Pattern.compile(EmailRegex);
	if (EmailPattern.matcher(email).matches()) {
	    return true;
	} else {
	    return false;
	}
    }
    
    public static final DecimalFormat CF = new DecimalFormat("0.00");
    
    public static String CurrencyFormatter(double amount) {
	return "RM " + CF.format(amount);
    }
    
    // Tester for CurrencyFormatter method
    /*
    public static void main(String[] args) {
	System.out.println(StringFormatter.CurrencyFormatter(234.5));
    }
    */
}
