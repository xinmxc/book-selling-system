/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class OrderFileHandler {
    private static final String OrderFilePath = "C:\\Users\\Jason\\Documents\\APU\\Sem 3\\Object Oriented Development for Java\\Group Assignment\\BundleBooks\\Order.txt";
    
    public ArrayList<Order> ReadObjectFromOrderFile() {
	try {
	    FileInputStream fileInput = new FileInputStream(OrderFilePath);
	    ObjectInputStream objInput = new ObjectInputStream(fileInput);
	    ArrayList<Order> orderArrList = (ArrayList<Order>) objInput.readObject();
	    return orderArrList;
	} catch (IOException | ClassNotFoundException e) {
	    System.out.println("Order.txt file DOES NOT EXIST!");
	    return null;
	}
    }
    
    public void WriteObjectToOrderFile(ArrayList<Order> arrList) {
	try {
	    FileOutputStream fileOutput = new FileOutputStream(OrderFilePath);
	    ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
	    objOutput.writeObject(arrList);
	} catch (IOException e) {
	    System.out.println("ERROR Occured");
	}
    }
}
