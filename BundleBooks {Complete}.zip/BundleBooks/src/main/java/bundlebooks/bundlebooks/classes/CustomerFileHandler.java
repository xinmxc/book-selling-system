/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class CustomerFileHandler {
    private static final String CustomerFilePath = "C:\\Users\\Jason\\Documents\\APU\\Sem 3\\Object Oriented Development for Java\\Group Assignment\\BundleBooks\\Customer.txt";
    
    public ArrayList<Customer> ReadObjectFromCustomerFile() {
	try {
	    FileInputStream fileInput = new FileInputStream(CustomerFilePath);
	    ObjectInputStream objInput = new ObjectInputStream(fileInput);
	    ArrayList<Customer> customerArrList = (ArrayList<Customer>) objInput.readObject();
	    return customerArrList;
	} catch (IOException | ClassNotFoundException e) {
	    System.out.println("Customer.txt file DOES NOT EXIST!");
	    return null;
	}
    }
    
    public void WriteObjectToCustomerFile(ArrayList<Customer> arrList) {
	try {
	    FileOutputStream fileOutput = new FileOutputStream(CustomerFilePath);
	    ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
	    objOutput.writeObject(arrList);
	} catch (IOException e) {
	    System.out.println("ERROR Occured");
	}
    }
}
