/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class AdminFileHandler {
    private static final String AdminFilePath = "C:\\Users\\Jason\\Documents\\APU\\Sem 3\\Object Oriented Development for Java\\Group Assignment\\BundleBooks\\Admin.txt";
    
    public ArrayList<Admin> ReadObjectFromAdminFile() {
	try {
	    FileInputStream fileInput = new FileInputStream(AdminFilePath);
	    ObjectInputStream objInput = new ObjectInputStream(fileInput);
	    ArrayList<Admin> adminArrList = (ArrayList<Admin>) objInput.readObject();
	    return adminArrList;
	} catch (IOException | ClassNotFoundException e) {
	    System.out.println("Admin.txt file DOES NOT EXIST!");
	    return null;
	}
    }
    
    public void WriteObjectToAdminFile(ArrayList<Admin> arrList) {
	try {
	    FileOutputStream fileOutput = new FileOutputStream(AdminFilePath);
	    ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
	    objOutput.writeObject(arrList);
	} catch (IOException e) {
	    System.out.println("ERROR Occured");
	}
    }
}
