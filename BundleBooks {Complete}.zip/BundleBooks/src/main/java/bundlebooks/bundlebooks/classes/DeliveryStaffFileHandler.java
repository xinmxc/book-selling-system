/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;
import java.io.*;
import java.util.*;
/**
 *
 * @author Jason
 */
public class DeliveryStaffFileHandler {
    private static final String DSFilePath = "C:\\Users\\Jason\\Documents\\APU\\Sem 3\\Object Oriented Development for Java\\Group Assignment\\BundleBooks\\DeliveryStaff.txt";
    
    public ArrayList<DeliveryStaff> ReadObjectFromDSFile() {
	try {
	    FileInputStream fileInput = new FileInputStream(DSFilePath);
	    ObjectInputStream objInput = new ObjectInputStream(fileInput);
	    ArrayList<DeliveryStaff> dSArrList = (ArrayList<DeliveryStaff>) objInput.readObject();
	    return dSArrList;
	} catch (IOException | ClassNotFoundException e) {
	    System.out.println("DeliveryStaff.txt file DOES NOT EXIST!");
	    return null;
	}
    }
    
    public void WriteObjectToDSFile(ArrayList<DeliveryStaff> arrList) {
	try {
	    FileOutputStream fileOutput = new FileOutputStream(DSFilePath);
	    ObjectOutputStream objOutput = new ObjectOutputStream(fileOutput);
	    objOutput.writeObject(arrList);
	} catch (IOException e) {
	    System.out.println("ERROR Occured");
	}
    }
}
