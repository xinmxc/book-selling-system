/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;

/**
 *
 * @author Jason
 */
public class BookIDFormatter {
    public final String BookIDFormatter(int id) {
	String formattedBookID = String.format("%06d", id);
	String bookIdentifier = "BK";
	String fullBookID = bookIdentifier + formattedBookID;
	return fullBookID;
    }
}
