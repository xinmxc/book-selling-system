/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bundlebooks.bundlebooks.classes;

/**
 *
 * @author jiaxi
 */
public class OrderIDFormatter {
    public final String OrderIDFormatter(int id) {
	String formattedOrderID = String.format("%07d", id);
	String orderIdentifier = "ODR";
	String fullOrderID = orderIdentifier + formattedOrderID;
	return fullOrderID;
    }
}
